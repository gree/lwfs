warn "Experimental features in the did_you_mean gem has been removed " \
     "and `require \"did_you_mean/experimental\"' has no effect."
