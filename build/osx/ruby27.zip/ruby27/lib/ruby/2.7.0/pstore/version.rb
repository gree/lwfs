class PStore
  VERSION = "0.1.0"
end
