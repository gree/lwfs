module EventMachine
  VERSION = "1.0.3"
end
