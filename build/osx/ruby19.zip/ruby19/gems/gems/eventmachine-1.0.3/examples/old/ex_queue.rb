require File.dirname(__FILE__) + '/helper'

