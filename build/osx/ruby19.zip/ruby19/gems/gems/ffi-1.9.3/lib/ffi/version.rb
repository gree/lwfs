module FFI
  VERSION = '1.9.3'
end

