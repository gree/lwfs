/* A Bison parser, made by GNU Bison 2.3.  */

/* Skeleton interface for Bison's Yacc-like parsers in C

   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
   Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor,
   Boston, MA 02110-1301, USA.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     BREAK = 258,
     FOR = 259,
     CONTINUE = 260,
     IF = 261,
     ELSE = 262,
     DO = 263,
     WHILE = 264,
     THIS = 265,
     EVAL = 266,
     TIME = 267,
     RANDOM = 268,
     LENGTH = 269,
     INT = 270,
     CONCAT = 271,
     DUPLICATECLIP = 272,
     REMOVECLIP = 273,
     TRACE = 274,
     STARTDRAG = 275,
     STOPDRAG = 276,
     ORD = 277,
     CHR = 278,
     CALLFRAME = 279,
     GETURL = 280,
     GETURL1 = 281,
     LOADMOVIE = 282,
     LOADMOVIENUM = 283,
     LOADVARIABLES = 284,
     POSTURL = 285,
     SUBSTR = 286,
     GETPROPERTY = 287,
     NEXTFRAME = 288,
     PREVFRAME = 289,
     PLAY = 290,
     STOP = 291,
     TOGGLEQUALITY = 292,
     STOPSOUNDS = 293,
     GOTOFRAME = 294,
     GOTOANDPLAY = 295,
     GOTOANDSTOP = 296,
     FRAMELOADED = 297,
     SETTARGET = 298,
     ASM = 299,
     ASMADD = 300,
     ASMDIVIDE = 301,
     ASMMULTIPLY = 302,
     ASMEQUALS = 303,
     ASMLESS = 304,
     ASMLOGICALAND = 305,
     ASMLOGICALOR = 306,
     ASMLOGICALNOT = 307,
     ASMSTRINGAND = 308,
     ASMSTRINGEQUALS = 309,
     ASMSTRINGEXTRACT = 310,
     ASMSTRINGLENGTH = 311,
     ASMMBSTRINGEXTRACT = 312,
     ASMMBSTRINGLENGTH = 313,
     ASMPOP = 314,
     ASMPUSH = 315,
     ASMASCIITOCHAR = 316,
     ASMCHARTOASCII = 317,
     ASMTOINTEGER = 318,
     ASMCALL = 319,
     ASMIF = 320,
     ASMJUMP = 321,
     ASMGETVARIABLE = 322,
     ASMSETVARIABLE = 323,
     ASMGETURL2 = 324,
     ASMGETPROPERTY = 325,
     ASMGOTOFRAME2 = 326,
     ASMREMOVESPRITE = 327,
     ASMSETPROPERTY = 328,
     ASMSETTARGET2 = 329,
     ASMSTARTDRAG = 330,
     ASMWAITFORFRAME2 = 331,
     ASMCLONESPRITE = 332,
     ASMENDDRAG = 333,
     ASMGETTIME = 334,
     ASMRANDOMNUMBER = 335,
     ASMTRACE = 336,
     ASMMBASCIITOCHAR = 337,
     ASMMBCHARTOASCII = 338,
     ASMSUBSTRACT = 339,
     ASMSTRINGLESS = 340,
     ASMEND = 341,
     TELLTARGET = 342,
     BROKENSTRING = 343,
     STRING = 344,
     NUMBER = 345,
     IDENTIFIER = 346,
     PATH = 347,
     EQ = 348,
     LE = 349,
     GE = 350,
     NE = 351,
     LAN = 352,
     LOR = 353,
     INC = 354,
     DEC = 355,
     IEQ = 356,
     DEQ = 357,
     MEQ = 358,
     SEQ = 359,
     STREQ = 360,
     STRNE = 361,
     STRCMP = 362,
     PARENT = 363,
     END = 364,
     UMINUS = 365,
     POSTFIX = 366,
     NEGATE = 367
   };
#endif
/* Tokens.  */
#define BREAK 258
#define FOR 259
#define CONTINUE 260
#define IF 261
#define ELSE 262
#define DO 263
#define WHILE 264
#define THIS 265
#define EVAL 266
#define TIME 267
#define RANDOM 268
#define LENGTH 269
#define INT 270
#define CONCAT 271
#define DUPLICATECLIP 272
#define REMOVECLIP 273
#define TRACE 274
#define STARTDRAG 275
#define STOPDRAG 276
#define ORD 277
#define CHR 278
#define CALLFRAME 279
#define GETURL 280
#define GETURL1 281
#define LOADMOVIE 282
#define LOADMOVIENUM 283
#define LOADVARIABLES 284
#define POSTURL 285
#define SUBSTR 286
#define GETPROPERTY 287
#define NEXTFRAME 288
#define PREVFRAME 289
#define PLAY 290
#define STOP 291
#define TOGGLEQUALITY 292
#define STOPSOUNDS 293
#define GOTOFRAME 294
#define GOTOANDPLAY 295
#define GOTOANDSTOP 296
#define FRAMELOADED 297
#define SETTARGET 298
#define ASM 299
#define ASMADD 300
#define ASMDIVIDE 301
#define ASMMULTIPLY 302
#define ASMEQUALS 303
#define ASMLESS 304
#define ASMLOGICALAND 305
#define ASMLOGICALOR 306
#define ASMLOGICALNOT 307
#define ASMSTRINGAND 308
#define ASMSTRINGEQUALS 309
#define ASMSTRINGEXTRACT 310
#define ASMSTRINGLENGTH 311
#define ASMMBSTRINGEXTRACT 312
#define ASMMBSTRINGLENGTH 313
#define ASMPOP 314
#define ASMPUSH 315
#define ASMASCIITOCHAR 316
#define ASMCHARTOASCII 317
#define ASMTOINTEGER 318
#define ASMCALL 319
#define ASMIF 320
#define ASMJUMP 321
#define ASMGETVARIABLE 322
#define ASMSETVARIABLE 323
#define ASMGETURL2 324
#define ASMGETPROPERTY 325
#define ASMGOTOFRAME2 326
#define ASMREMOVESPRITE 327
#define ASMSETPROPERTY 328
#define ASMSETTARGET2 329
#define ASMSTARTDRAG 330
#define ASMWAITFORFRAME2 331
#define ASMCLONESPRITE 332
#define ASMENDDRAG 333
#define ASMGETTIME 334
#define ASMRANDOMNUMBER 335
#define ASMTRACE 336
#define ASMMBASCIITOCHAR 337
#define ASMMBCHARTOASCII 338
#define ASMSUBSTRACT 339
#define ASMSTRINGLESS 340
#define ASMEND 341
#define TELLTARGET 342
#define BROKENSTRING 343
#define STRING 344
#define NUMBER 345
#define IDENTIFIER 346
#define PATH 347
#define EQ 348
#define LE 349
#define GE 350
#define NE 351
#define LAN 352
#define LOR 353
#define INC 354
#define DEC 355
#define IEQ 356
#define DEQ 357
#define MEQ 358
#define SEQ 359
#define STREQ 360
#define STRNE 361
#define STRCMP 362
#define PARENT 363
#define END 364
#define UMINUS 365
#define POSTFIX 366
#define NEGATE 367




#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
#line 19 "swf4compiler.y"
{
  Buffer action;
  char *str;
  SWFActionFunction function;
  SWFGetUrl2Method getURLMethod;
  int len;
}
/* Line 1529 of yacc.c.  */
#line 281 "swf4compiler.tab.h"
	YYSTYPE;
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif

extern YYSTYPE swf4lval;

