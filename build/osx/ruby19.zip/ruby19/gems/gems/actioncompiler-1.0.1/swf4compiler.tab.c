/* A Bison parser, made by GNU Bison 2.3.  */

/* Skeleton implementation for Bison's Yacc-like parsers in C

   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
   Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor,
   Boston, MA 02110-1301, USA.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output.  */
#define YYBISON 1

/* Bison version.  */
#define YYBISON_VERSION "2.3"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Using locations.  */
#define YYLSP_NEEDED 0

/* Substitute the variable and function names.  */
#define yyparse swf4parse
#define yylex   swf4lex
#define yyerror swf4error
#define yylval  swf4lval
#define yychar  swf4char
#define yydebug swf4debug
#define yynerrs swf4nerrs


/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     BREAK = 258,
     FOR = 259,
     CONTINUE = 260,
     IF = 261,
     ELSE = 262,
     DO = 263,
     WHILE = 264,
     THIS = 265,
     EVAL = 266,
     TIME = 267,
     RANDOM = 268,
     LENGTH = 269,
     INT = 270,
     CONCAT = 271,
     DUPLICATECLIP = 272,
     REMOVECLIP = 273,
     TRACE = 274,
     STARTDRAG = 275,
     STOPDRAG = 276,
     ORD = 277,
     CHR = 278,
     CALLFRAME = 279,
     GETURL = 280,
     GETURL1 = 281,
     LOADMOVIE = 282,
     LOADMOVIENUM = 283,
     LOADVARIABLES = 284,
     POSTURL = 285,
     SUBSTR = 286,
     GETPROPERTY = 287,
     NEXTFRAME = 288,
     PREVFRAME = 289,
     PLAY = 290,
     STOP = 291,
     TOGGLEQUALITY = 292,
     STOPSOUNDS = 293,
     GOTOFRAME = 294,
     GOTOANDPLAY = 295,
     GOTOANDSTOP = 296,
     FRAMELOADED = 297,
     SETTARGET = 298,
     ASM = 299,
     ASMADD = 300,
     ASMDIVIDE = 301,
     ASMMULTIPLY = 302,
     ASMEQUALS = 303,
     ASMLESS = 304,
     ASMLOGICALAND = 305,
     ASMLOGICALOR = 306,
     ASMLOGICALNOT = 307,
     ASMSTRINGAND = 308,
     ASMSTRINGEQUALS = 309,
     ASMSTRINGEXTRACT = 310,
     ASMSTRINGLENGTH = 311,
     ASMMBSTRINGEXTRACT = 312,
     ASMMBSTRINGLENGTH = 313,
     ASMPOP = 314,
     ASMPUSH = 315,
     ASMASCIITOCHAR = 316,
     ASMCHARTOASCII = 317,
     ASMTOINTEGER = 318,
     ASMCALL = 319,
     ASMIF = 320,
     ASMJUMP = 321,
     ASMGETVARIABLE = 322,
     ASMSETVARIABLE = 323,
     ASMGETURL2 = 324,
     ASMGETPROPERTY = 325,
     ASMGOTOFRAME2 = 326,
     ASMREMOVESPRITE = 327,
     ASMSETPROPERTY = 328,
     ASMSETTARGET2 = 329,
     ASMSTARTDRAG = 330,
     ASMWAITFORFRAME2 = 331,
     ASMCLONESPRITE = 332,
     ASMENDDRAG = 333,
     ASMGETTIME = 334,
     ASMRANDOMNUMBER = 335,
     ASMTRACE = 336,
     ASMMBASCIITOCHAR = 337,
     ASMMBCHARTOASCII = 338,
     ASMSUBSTRACT = 339,
     ASMSTRINGLESS = 340,
     TELLTARGET = 341,
     BROKENSTRING = 342,
     STRING = 343,
     NUMBER = 344,
     IDENTIFIER = 345,
     PATH = 346,
     EQ = 347,
     LE = 348,
     GE = 349,
     NE = 350,
     LAN = 351,
     LOR = 352,
     INC = 353,
     DEC = 354,
     IEQ = 355,
     DEQ = 356,
     MEQ = 357,
     SEQ = 358,
     STREQ = 359,
     STRNE = 360,
     STRCMP = 361,
     PARENT = 362,
     END = 363,
     UMINUS = 364,
     POSTFIX = 365,
     NEGATE = 366
   };
#endif
/* Tokens.  */
#define BREAK 258
#define FOR 259
#define CONTINUE 260
#define IF 261
#define ELSE 262
#define DO 263
#define WHILE 264
#define THIS 265
#define EVAL 266
#define TIME 267
#define RANDOM 268
#define LENGTH 269
#define INT 270
#define CONCAT 271
#define DUPLICATECLIP 272
#define REMOVECLIP 273
#define TRACE 274
#define STARTDRAG 275
#define STOPDRAG 276
#define ORD 277
#define CHR 278
#define CALLFRAME 279
#define GETURL 280
#define GETURL1 281
#define LOADMOVIE 282
#define LOADMOVIENUM 283
#define LOADVARIABLES 284
#define POSTURL 285
#define SUBSTR 286
#define GETPROPERTY 287
#define NEXTFRAME 288
#define PREVFRAME 289
#define PLAY 290
#define STOP 291
#define TOGGLEQUALITY 292
#define STOPSOUNDS 293
#define GOTOFRAME 294
#define GOTOANDPLAY 295
#define GOTOANDSTOP 296
#define FRAMELOADED 297
#define SETTARGET 298
#define ASM 299
#define ASMADD 300
#define ASMDIVIDE 301
#define ASMMULTIPLY 302
#define ASMEQUALS 303
#define ASMLESS 304
#define ASMLOGICALAND 305
#define ASMLOGICALOR 306
#define ASMLOGICALNOT 307
#define ASMSTRINGAND 308
#define ASMSTRINGEQUALS 309
#define ASMSTRINGEXTRACT 310
#define ASMSTRINGLENGTH 311
#define ASMMBSTRINGEXTRACT 312
#define ASMMBSTRINGLENGTH 313
#define ASMPOP 314
#define ASMPUSH 315
#define ASMASCIITOCHAR 316
#define ASMCHARTOASCII 317
#define ASMTOINTEGER 318
#define ASMCALL 319
#define ASMIF 320
#define ASMJUMP 321
#define ASMGETVARIABLE 322
#define ASMSETVARIABLE 323
#define ASMGETURL2 324
#define ASMGETPROPERTY 325
#define ASMGOTOFRAME2 326
#define ASMREMOVESPRITE 327
#define ASMSETPROPERTY 328
#define ASMSETTARGET2 329
#define ASMSTARTDRAG 330
#define ASMWAITFORFRAME2 331
#define ASMCLONESPRITE 332
#define ASMENDDRAG 333
#define ASMGETTIME 334
#define ASMRANDOMNUMBER 335
#define ASMTRACE 336
#define ASMMBASCIITOCHAR 337
#define ASMMBCHARTOASCII 338
#define ASMSUBSTRACT 339
#define ASMSTRINGLESS 340
#define TELLTARGET 341
#define BROKENSTRING 342
#define STRING 343
#define NUMBER 344
#define IDENTIFIER 345
#define PATH 346
#define EQ 347
#define LE 348
#define GE 349
#define NE 350
#define LAN 351
#define LOR 352
#define INC 353
#define DEC 354
#define IEQ 355
#define DEQ 356
#define MEQ 357
#define SEQ 358
#define STREQ 359
#define STRNE 360
#define STRCMP 361
#define PARENT 362
#define END 363
#define UMINUS 364
#define POSTFIX 365
#define NEGATE 366




/* Copy the first part of user declarations.  */
#line 5 "swf4compiler.y"


#include <time.h>
#include <string.h>
#include <stdlib.h>
#include "compile.h"
#include "actiontypes.h"
#include "assembler.h"

#define YYPARSE_PARAM buffer
#define YYERROR_VERBOSE 1



/* Enabling traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif

/* Enabling verbose error messages.  */
#ifdef YYERROR_VERBOSE
# undef YYERROR_VERBOSE
# define YYERROR_VERBOSE 1
#else
# define YYERROR_VERBOSE 0
#endif

/* Enabling the token table.  */
#ifndef YYTOKEN_TABLE
# define YYTOKEN_TABLE 0
#endif

#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
#line 19 "swf4compiler.y"
{
  Buffer action;
  char *str;
  SWFActionFunction function;
  SWFGetUrl2Method getURLMethod;
  int len;
}
/* Line 193 of yacc.c.  */
#line 348 "swf4compiler.tab.c"
	YYSTYPE;
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif



/* Copy the second part of user declarations.  */


/* Line 216 of yacc.c.  */
#line 361 "swf4compiler.tab.c"

#ifdef short
# undef short
#endif

#ifdef YYTYPE_UINT8
typedef YYTYPE_UINT8 yytype_uint8;
#else
typedef unsigned char yytype_uint8;
#endif

#ifdef YYTYPE_INT8
typedef YYTYPE_INT8 yytype_int8;
#elif (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
typedef signed char yytype_int8;
#else
typedef short int yytype_int8;
#endif

#ifdef YYTYPE_UINT16
typedef YYTYPE_UINT16 yytype_uint16;
#else
typedef unsigned short int yytype_uint16;
#endif

#ifdef YYTYPE_INT16
typedef YYTYPE_INT16 yytype_int16;
#else
typedef short int yytype_int16;
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif ! defined YYSIZE_T && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned int
# endif
#endif

#define YYSIZE_MAXIMUM ((YYSIZE_T) -1)

#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(msgid) dgettext ("bison-runtime", msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(msgid) msgid
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YYUSE(e) ((void) (e))
#else
# define YYUSE(e) /* empty */
#endif

/* Identity function, used to suppress warnings about constant conditions.  */
#ifndef lint
# define YYID(n) (n)
#else
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static int
YYID (int i)
#else
static int
YYID (i)
    int i;
#endif
{
  return i;
}
#endif

#if ! defined yyoverflow || YYERROR_VERBOSE

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#     ifndef _STDLIB_H
#      define _STDLIB_H 1
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's `empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (YYID (0))
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined _STDLIB_H \
       && ! ((defined YYMALLOC || defined malloc) \
	     && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef _STDLIB_H
#    define _STDLIB_H 1
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* ! defined yyoverflow || YYERROR_VERBOSE */


#if (! defined yyoverflow \
     && (! defined __cplusplus \
	 || (defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yytype_int16 yyss;
  YYSTYPE yyvs;
  };

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (sizeof (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (sizeof (yytype_int16) + sizeof (YYSTYPE)) \
      + YYSTACK_GAP_MAXIMUM)

/* Copy COUNT objects from FROM to TO.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(To, From, Count) \
      __builtin_memcpy (To, From, (Count) * sizeof (*(From)))
#  else
#   define YYCOPY(To, From, Count)		\
      do					\
	{					\
	  YYSIZE_T yyi;				\
	  for (yyi = 0; yyi < (Count); yyi++)	\
	    (To)[yyi] = (From)[yyi];		\
	}					\
      while (YYID (0))
#  endif
# endif

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack)					\
    do									\
      {									\
	YYSIZE_T yynewbytes;						\
	YYCOPY (&yyptr->Stack, Stack, yysize);				\
	Stack = &yyptr->Stack;						\
	yynewbytes = yystacksize * sizeof (*Stack) + YYSTACK_GAP_MAXIMUM; \
	yyptr += yynewbytes / sizeof (*yyptr);				\
      }									\
    while (YYID (0))

#endif

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  114
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   1604

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  130
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  30
/* YYNRULES -- Number of rules.  */
#define YYNRULES  190
/* YYNRULES -- Number of states.  */
#define YYNSTATES  439

/* YYTRANSLATE(YYLEX) -- Bison symbol number corresponding to YYLEX.  */
#define YYUNDEFTOK  2
#define YYMAXUTOK   366

#define YYTRANSLATE(YYX)						\
  ((unsigned int) (YYX) <= YYMAXUTOK ? yytranslate[YYX] : YYUNDEFTOK)

/* YYTRANSLATE[YYLEX] -- Bison symbol number corresponding to YYLEX.  */
static const yytype_uint8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,   120,     2,     2,     2,     2,   115,     2,
     127,   128,   118,   116,   109,   117,   129,   119,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,   112,   126,
     113,   110,   114,   111,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,   124,     2,   125,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
      75,    76,    77,    78,    79,    80,    81,    82,    83,    84,
      85,    86,    87,    88,    89,    90,    91,    92,    93,    94,
      95,    96,    97,    98,    99,   100,   101,   102,   103,   104,
     105,   106,   107,   108,   121,   122,   123
};

#if YYDEBUG
/* YYPRHS[YYN] -- Index of the first RHS symbol of rule number YYN in
   YYRHS.  */
static const yytype_uint16 yyprhs[] =
{
       0,     0,     3,     5,     7,    10,    12,    15,    19,    21,
      24,    26,    28,    30,    32,    34,    38,    39,    41,    44,
      55,    64,    74,    85,    94,   104,   112,   118,   119,   121,
     131,   137,   144,   154,   155,   157,   160,   163,   164,   167,
     169,   173,   178,   183,   188,   193,   200,   208,   215,   223,
     231,   239,   246,   261,   270,   274,   278,   282,   286,   290,
     294,   299,   304,   309,   314,   319,   324,   329,   334,   340,
     346,   351,   355,   360,   365,   370,   375,   380,   387,   396,
     403,   406,   409,   411,   415,   417,   420,   422,   424,   426,
     430,   435,   438,   443,   446,   449,   452,   456,   460,   464,
     468,   472,   476,   480,   484,   488,   492,   496,   500,   504,
     508,   512,   516,   520,   526,   528,   532,   534,   536,   538,
     540,   542,   544,   546,   548,   552,   554,   555,   561,   563,
     566,   569,   574,   579,   583,   587,   591,   595,   599,   605,
     611,   617,   623,   629,   631,   633,   635,   639,   641,   644,
     645,   649,   651,   653,   655,   657,   659,   661,   663,   665,
     667,   669,   671,   673,   675,   677,   679,   681,   683,   685,
     687,   689,   691,   693,   695,   697,   699,   701,   703,   705,
     707,   709,   711,   713,   715,   717,   719,   722,   725,   728,
     731
};

/* YYRHS -- A `-1'-separated list of the rules' RHS.  */
static const yytype_int16 yyrhs[] =
{
     131,     0,    -1,   132,    -1,   133,    -1,   132,   133,    -1,
     134,    -1,   124,   125,    -1,   124,   136,   125,    -1,   126,
      -1,   152,   126,    -1,   137,    -1,   139,    -1,   141,    -1,
     142,    -1,   152,    -1,   135,   109,   152,    -1,    -1,   134,
      -1,   136,   134,    -1,     6,   127,    42,   127,    89,   128,
     128,   134,     7,   134,    -1,     6,   127,    42,   127,    89,
     128,   128,   134,    -1,     6,   127,   120,    42,   127,    89,
     128,   128,   134,    -1,     6,   127,    42,   127,   154,   128,
     128,   134,     7,   134,    -1,     6,   127,    42,   127,   154,
     128,   128,   134,    -1,     6,   127,   120,    42,   127,   154,
     128,   128,   134,    -1,     6,   127,   154,   128,   134,     7,
     134,    -1,     6,   127,   154,   128,   134,    -1,    -1,   154,
      -1,     9,   127,   120,    42,   127,    89,   128,   128,   134,
      -1,     9,   127,   154,   128,   134,    -1,     8,   134,     9,
     127,   154,   128,    -1,     4,   127,   140,   126,   138,   126,
     140,   128,   134,    -1,    -1,   135,    -1,     5,   126,    -1,
       3,   126,    -1,    -1,   109,    88,    -1,   154,    -1,    21,
     127,   128,    -1,    24,   127,   149,   128,    -1,    24,   127,
      88,   128,    -1,    18,   127,   154,   128,    -1,    19,   127,
     154,   128,    -1,    25,   127,   154,   109,   154,   128,    -1,
      25,   127,   154,   109,   154,   143,   128,    -1,    26,   127,
      88,   109,    88,   128,    -1,    27,   127,   154,   109,   154,
     143,   128,    -1,    28,   127,   154,   109,   144,   143,   128,
      -1,    29,   127,   154,   109,   154,   143,   128,    -1,    20,
     127,   154,   109,   154,   128,    -1,    20,   127,   154,   109,
     154,   109,   154,   109,   154,   109,   154,   109,   154,   128,
      -1,    17,   127,   154,   109,   154,   109,   154,   128,    -1,
      33,   127,   128,    -1,    34,   127,   128,    -1,    35,   127,
     128,    -1,    36,   127,   128,    -1,    37,   127,   128,    -1,
      38,   127,   128,    -1,    39,   127,    89,   128,    -1,    39,
     127,    88,   128,    -1,    40,   127,    89,   128,    -1,    40,
     127,    88,   128,    -1,    41,   127,    89,   128,    -1,    41,
     127,    88,   128,    -1,    43,   127,    88,   128,    -1,    43,
     127,   154,   128,    -1,    86,   127,    88,   128,   134,    -1,
      86,   127,   154,   128,   134,    -1,    11,   127,   154,   128,
      -1,    12,   127,   128,    -1,    13,   127,   154,   128,    -1,
      14,   127,   154,   128,    -1,    15,   127,   154,   128,    -1,
      22,   127,   154,   128,    -1,    23,   127,   154,   128,    -1,
      16,   127,   154,   109,   154,   128,    -1,    31,   127,   154,
     109,   154,   109,   154,   128,    -1,    32,   127,   154,   109,
      88,   128,    -1,   151,    98,    -1,   151,    99,    -1,   146,
      -1,   127,   148,   128,    -1,    89,    -1,   117,    89,    -1,
      88,    -1,   149,    -1,   150,    -1,   150,   129,    90,    -1,
      98,   150,   129,    90,    -1,    98,   151,    -1,    99,   150,
     129,    90,    -1,    99,   151,    -1,   117,   148,    -1,   120,
     148,    -1,   151,   110,   148,    -1,   148,   118,   148,    -1,
     148,   119,   148,    -1,   148,   116,   148,    -1,   148,   117,
     148,    -1,   148,   115,   148,    -1,   148,   113,   148,    -1,
     148,   114,   148,    -1,   148,    93,   148,    -1,   148,    94,
     148,    -1,   148,   105,   148,    -1,   148,   104,   148,    -1,
     148,   106,   148,    -1,   148,    92,   148,    -1,   148,    95,
     148,    -1,   148,    96,   148,    -1,   148,    97,   148,    -1,
     148,   111,   148,   112,   148,    -1,    90,    -1,   150,   112,
      90,    -1,    10,    -1,   129,    -1,   119,    -1,   107,    -1,
      90,    -1,    91,    -1,   149,    -1,    88,    -1,   127,   148,
     128,    -1,   147,    -1,    -1,    44,   124,   153,   157,   125,
      -1,   145,    -1,    98,   151,    -1,    99,   151,    -1,    98,
     150,   129,    90,    -1,    99,   150,   129,    90,    -1,   151,
     110,   148,    -1,   151,   102,   148,    -1,   151,   101,   148,
      -1,   151,   100,   148,    -1,   151,   103,   148,    -1,   150,
     129,    90,   110,   148,    -1,   150,   129,    90,   102,   148,
      -1,   150,   129,    90,   101,   148,    -1,   150,   129,    90,
     100,   148,    -1,   150,   129,    90,   103,   148,    -1,   148,
      -1,    88,    -1,   155,    -1,   156,   109,   155,    -1,   158,
      -1,   157,   158,    -1,    -1,    60,   159,   156,    -1,    45,
      -1,    84,    -1,    47,    -1,    46,    -1,    48,    -1,    49,
      -1,    50,    -1,    51,    -1,    52,    -1,    53,    -1,    54,
      -1,    56,    -1,    55,    -1,    57,    -1,    58,    -1,    85,
      -1,    59,    -1,    61,    -1,    62,    -1,    63,    -1,    82,
      -1,    83,    -1,    64,    -1,    67,    -1,    68,    -1,    70,
      -1,    73,    -1,    72,    -1,    74,    -1,    75,    -1,    78,
      -1,    77,    -1,    79,    -1,    80,    -1,    81,    -1,    65,
      89,    -1,    66,    89,    -1,    69,    89,    -1,    71,    89,
      -1,    76,    89,    -1
};

/* YYRLINE[YYN] -- source line where rule number YYN was defined.  */
static const yytype_uint16 yyrline[] =
{
       0,   164,   164,   170,   171,   176,   180,   181,   182,   183,
     184,   185,   186,   187,   191,   192,   196,   197,   198,   205,
     221,   237,   249,   263,   277,   287,   298,   308,   309,   333,
     348,   360,   368,   390,   391,   395,   403,   412,   414,   421,
     429,   433,   440,   447,   451,   456,   463,   470,   479,   486,
     493,   501,   508,   520,   529,   533,   537,   541,   545,   549,
     553,   560,   567,   575,   583,   591,   599,   606,   610,   624,
     637,   641,   645,   649,   653,   657,   661,   665,   670,   676,
     685,   696,   710,   712,   715,   720,   726,   731,   737,   742,
     750,   765,   775,   790,   800,   805,   809,   815,   820,   825,
     830,   835,   840,   845,   850,   856,   861,   866,   870,   874,
     878,   883,   887,   891,   903,   905,   912,   915,   918,   921,
     924,   927,   932,   937,   942,   946,   949,   948,   953,   955,
     963,   971,   984,   997,  1001,  1008,  1015,  1022,  1029,  1038,
    1051,  1064,  1077,  1092,  1096,  1100,  1101,  1105,  1106,  1110,
    1110,  1116,  1117,  1118,  1119,  1120,  1121,  1122,  1123,  1124,
    1125,  1126,  1127,  1128,  1129,  1130,  1131,  1132,  1133,  1134,
    1135,  1136,  1137,  1138,  1139,  1140,  1141,  1142,  1143,  1144,
    1145,  1146,  1147,  1148,  1149,  1150,  1152,  1156,  1160,  1163,
    1167
};
#endif

#if YYDEBUG || YYERROR_VERBOSE || YYTOKEN_TABLE
/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "$end", "error", "$undefined", "BREAK", "FOR", "CONTINUE", "IF", "ELSE",
  "DO", "WHILE", "THIS", "EVAL", "TIME", "RANDOM", "LENGTH", "INT",
  "CONCAT", "DUPLICATECLIP", "REMOVECLIP", "TRACE", "STARTDRAG",
  "STOPDRAG", "ORD", "CHR", "CALLFRAME", "GETURL", "GETURL1", "LOADMOVIE",
  "LOADMOVIENUM", "LOADVARIABLES", "POSTURL", "SUBSTR", "GETPROPERTY",
  "NEXTFRAME", "PREVFRAME", "PLAY", "STOP", "TOGGLEQUALITY", "STOPSOUNDS",
  "GOTOFRAME", "GOTOANDPLAY", "GOTOANDSTOP", "FRAMELOADED", "SETTARGET",
  "ASM", "ASMADD", "ASMDIVIDE", "ASMMULTIPLY", "ASMEQUALS", "ASMLESS",
  "ASMLOGICALAND", "ASMLOGICALOR", "ASMLOGICALNOT", "ASMSTRINGAND",
  "ASMSTRINGEQUALS", "ASMSTRINGEXTRACT", "ASMSTRINGLENGTH",
  "ASMMBSTRINGEXTRACT", "ASMMBSTRINGLENGTH", "ASMPOP", "ASMPUSH",
  "ASMASCIITOCHAR", "ASMCHARTOASCII", "ASMTOINTEGER", "ASMCALL", "ASMIF",
  "ASMJUMP", "ASMGETVARIABLE", "ASMSETVARIABLE", "ASMGETURL2",
  "ASMGETPROPERTY", "ASMGOTOFRAME2", "ASMREMOVESPRITE", "ASMSETPROPERTY",
  "ASMSETTARGET2", "ASMSTARTDRAG", "ASMWAITFORFRAME2", "ASMCLONESPRITE",
  "ASMENDDRAG", "ASMGETTIME", "ASMRANDOMNUMBER", "ASMTRACE",
  "ASMMBASCIITOCHAR", "ASMMBCHARTOASCII", "ASMSUBSTRACT", "ASMSTRINGLESS",
  "TELLTARGET", "BROKENSTRING", "STRING", "NUMBER", "IDENTIFIER", "PATH",
  "\"==\"", "\"<=\"", "\">=\"", "\"!=\"", "\"&&\"", "\"||\"", "\"++\"",
  "\"--\"", "\"+=\"", "\"/=\"", "\"*=\"", "\"-=\"", "\"===\"", "\"!==\"",
  "\"<=>\"", "\"..\"", "\"end\"", "','", "'='", "'?'", "':'", "'<'", "'>'",
  "'&'", "'+'", "'-'", "'*'", "'/'", "'!'", "UMINUS", "POSTFIX", "NEGATE",
  "'{'", "'}'", "';'", "'('", "')'", "'.'", "$accept", "program", "elems",
  "elem", "stmt", "assign_stmts", "statements", "if_stmt", "expr_opt",
  "iter_stmt", "assign_stmts_opt", "cont_stmt", "break_stmt", "urlmethod",
  "level", "void_function_call", "function_call", "pf_expr", "rhs_expr",
  "variable", "sprite", "lhs_expr", "assign_stmt", "@1", "expr",
  "push_item", "push_list", "opcode_list", "opcode", "@2", 0
};
#endif

# ifdef YYPRINT
/* YYTOKNUM[YYLEX-NUM] -- Internal token number corresponding to
   token YYLEX-NUM.  */
static const yytype_uint16 yytoknum[] =
{
       0,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,   283,   284,
     285,   286,   287,   288,   289,   290,   291,   292,   293,   294,
     295,   296,   297,   298,   299,   300,   301,   302,   303,   304,
     305,   306,   307,   308,   309,   310,   311,   312,   313,   314,
     315,   316,   317,   318,   319,   320,   321,   322,   323,   324,
     325,   326,   327,   328,   329,   330,   331,   332,   333,   334,
     335,   336,   337,   338,   339,   340,   341,   342,   343,   344,
     345,   346,   347,   348,   349,   350,   351,   352,   353,   354,
     355,   356,   357,   358,   359,   360,   361,   362,   363,    44,
      61,    63,    58,    60,    62,    38,    43,    45,    42,    47,
      33,   364,   365,   366,   123,   125,    59,    40,    41,    46
};
# endif

/* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const yytype_uint8 yyr1[] =
{
       0,   130,   131,   132,   132,   133,   134,   134,   134,   134,
     134,   134,   134,   134,   135,   135,   136,   136,   136,   137,
     137,   137,   137,   137,   137,   137,   137,   138,   138,   139,
     139,   139,   139,   140,   140,   141,   142,   143,   143,   144,
     145,   145,   145,   145,   145,   145,   145,   145,   145,   145,
     145,   145,   145,   145,   145,   145,   145,   145,   145,   145,
     145,   145,   145,   145,   145,   145,   145,   145,   145,   145,
     146,   146,   146,   146,   146,   146,   146,   146,   146,   146,
     147,   147,   148,   148,   148,   148,   148,   148,   148,   148,
     148,   148,   148,   148,   148,   148,   148,   148,   148,   148,
     148,   148,   148,   148,   148,   148,   148,   148,   148,   148,
     148,   148,   148,   148,   149,   149,   150,   150,   150,   150,
     150,   150,   151,   151,   151,   152,   153,   152,   152,   152,
     152,   152,   152,   152,   152,   152,   152,   152,   152,   152,
     152,   152,   152,   154,   155,   156,   156,   157,   157,   159,
     158,   158,   158,   158,   158,   158,   158,   158,   158,   158,
     158,   158,   158,   158,   158,   158,   158,   158,   158,   158,
     158,   158,   158,   158,   158,   158,   158,   158,   158,   158,
     158,   158,   158,   158,   158,   158,   158,   158,   158,   158,
     158
};

/* YYR2[YYN] -- Number of symbols composing right hand side of rule YYN.  */
static const yytype_uint8 yyr2[] =
{
       0,     2,     1,     1,     2,     1,     2,     3,     1,     2,
       1,     1,     1,     1,     1,     3,     0,     1,     2,    10,
       8,     9,    10,     8,     9,     7,     5,     0,     1,     9,
       5,     6,     9,     0,     1,     2,     2,     0,     2,     1,
       3,     4,     4,     4,     4,     6,     7,     6,     7,     7,
       7,     6,    14,     8,     3,     3,     3,     3,     3,     3,
       4,     4,     4,     4,     4,     4,     4,     4,     5,     5,
       4,     3,     4,     4,     4,     4,     4,     6,     8,     6,
       2,     2,     1,     3,     1,     2,     1,     1,     1,     3,
       4,     2,     4,     2,     2,     2,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     5,     1,     3,     1,     1,     1,     1,
       1,     1,     1,     1,     3,     1,     0,     5,     1,     2,
       2,     4,     4,     3,     3,     3,     3,     3,     5,     5,
       5,     5,     5,     1,     1,     1,     3,     1,     2,     0,
       3,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     2,     2,     2,     2,
       2
};

/* YYDEFACT[STATE-NAME] -- Default rule to reduce with in state
   STATE-NUM when YYTABLE doesn't specify something else to do.  Zero
   means the default is an error.  */
static const yytype_uint8 yydefact[] =
{
       0,     0,     0,     0,     0,     0,     0,   116,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   123,   114,   121,     0,     0,   119,   118,     0,     8,
       0,   117,     0,     2,     3,     5,    10,    11,    12,    13,
     128,   125,   122,     0,     0,     0,    36,    33,    35,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   126,     0,     0,   129,     0,   130,     6,
      17,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,    86,    84,     0,     0,     0,     0,     0,    82,
       0,    87,    88,     0,     1,     4,     0,     0,    80,    81,
       0,     0,     0,     0,     0,     9,    34,     0,    14,     0,
       0,   143,     0,     0,     0,     0,     0,     0,     0,     0,
      40,     0,     0,     0,     0,     0,     0,     0,     0,    54,
      55,    56,    57,    58,    59,     0,     0,     0,     0,     0,
       0,    86,     0,     0,    86,     0,     0,     0,     7,    18,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,    91,     0,    93,    84,    94,    95,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   124,     0,     0,   115,     0,
     136,   135,   134,   137,   133,     0,    27,     0,     0,     0,
       0,     0,     0,     0,    43,    44,     0,    42,    41,     0,
       0,     0,     0,     0,    61,    60,    63,    62,    65,    64,
      66,    67,   151,   154,   153,   155,   156,   157,   158,   159,
     160,   161,   163,   162,   164,   165,   167,   149,   168,   169,
     170,   173,     0,     0,   174,   175,     0,   176,     0,   178,
     177,   179,   180,     0,   182,   181,   183,   184,   185,   171,
     172,   152,   166,     0,   147,     0,     0,   131,   132,     0,
      71,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,    83,   109,   104,   105,   110,   111,   112,   107,   106,
     108,     0,   102,   103,   101,    99,   100,    97,    98,    89,
      96,     0,     0,     0,     0,     0,    15,     0,    28,    84,
       0,     0,    26,     0,     0,    30,     0,     0,     0,     0,
      37,    37,    39,    37,     0,   186,   187,   188,   189,   190,
     127,   148,    68,    69,    70,    72,    73,    74,     0,    75,
      76,     0,     0,    90,    92,     0,   141,   140,   139,   142,
     138,    33,     0,     0,    84,     0,     0,    31,     0,     0,
       0,    51,     0,    45,     0,    47,     0,     0,     0,   144,
     145,   150,     0,     0,     0,   113,     0,     0,     0,     0,
       0,    25,     0,     0,     0,    38,    46,    48,    49,    50,
       0,    77,     0,    79,     0,    20,    23,     0,     0,     0,
      53,     0,   146,     0,    32,     0,     0,    21,    24,    29,
       0,    78,    19,    22,     0,     0,     0,     0,    52
};

/* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int16 yydefgoto[] =
{
      -1,    42,    43,    44,    45,   126,    91,    46,   327,    47,
     127,    48,    49,   384,   341,    50,   109,    51,   131,   111,
     112,   113,    55,   163,   132,   390,   391,   283,   284,   344
};

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
#define YYPACT_NINF -271
static const yytype_int16 yypact[] =
{
     841,  -124,  -116,  -112,  -105,   841,   -94,  -271,   -86,   -81,
     -75,   -67,   -58,   -48,   -42,   -37,   -29,   -27,   -16,   -15,
     -14,   -13,   -10,    -6,    -5,    -3,    -1,     1,     2,   -62,
       5,  -271,   -63,  -271,    -4,    -4,  -271,  -271,   587,  -271,
    1119,  -271,   127,   841,  -271,  -271,  -271,  -271,  -271,  -271,
    -271,  -271,  -271,   -73,    36,     7,  -271,   873,  -271,   963,
     132,  1133,  1119,  1119,  1119,  1119,    14,    11,  1119,    55,
    1119,  1119,  1119,    19,    26,    27,    28,    29,    30,   -34,
     -12,    -8,  1253,  -271,  1267,   -70,  -271,   -68,  -271,  -271,
    -271,   714,    37,    38,    39,    41,    49,    50,    59,    63,
      64,    65,    53,  -271,    -4,    -4,  1300,  1119,  1119,  -271,
      56,    73,   -65,    83,  -271,  -271,   104,   105,  -271,  -271,
    1119,  1119,  1119,  1119,  1119,  -271,    87,    71,  -271,    75,
     996,   540,    70,    76,  1086,    72,    95,    77,    78,    98,
    -271,    80,    81,    99,   101,   103,   107,   108,   109,  -271,
    -271,  -271,  -271,  -271,  -271,    85,    86,    92,    93,    96,
      97,   -92,   100,  1519,   -91,   110,   133,   136,  -271,  -271,
    1119,   111,  1119,  1119,  1119,  1119,  1119,  1119,  1119,  1119,
     -64,  -271,   -61,  -271,  -271,  -271,  -271,   264,  1119,  1119,
    1119,  1119,  1119,  1119,  1119,  1119,  1119,  1119,  1119,  1119,
    1119,  1119,  1119,  1119,  1119,  -271,   137,  1119,  -271,   -93,
     540,   540,   540,   540,   540,   873,  1119,  1314,   102,   841,
    1119,   106,   841,  1119,  -271,  -271,  1119,  -271,  -271,  1119,
     143,  1119,  1119,  1119,  -271,  -271,  -271,  -271,  -271,  -271,
    -271,  -271,  -271,  -271,  -271,  -271,  -271,  -271,  -271,  -271,
    -271,  -271,  -271,  -271,  -271,  -271,  -271,  -271,  -271,  -271,
    -271,  -271,   146,   147,  -271,  -271,   151,  -271,   152,  -271,
    -271,  -271,  -271,   153,  -271,  -271,  -271,  -271,  -271,  -271,
    -271,  -271,  -271,  1422,  -271,   841,   841,  -271,  -271,   115,
    -271,   118,   120,   121,   123,   122,   128,   148,   149,   155,
     170,   156,   -90,   -23,   -23,   -90,   159,   159,   -90,   -90,
     -23,   428,   -23,   -23,    -9,   -30,   -30,  -271,  -271,  -271,
     540,  1119,  1119,  1119,  1119,  1119,  -271,   135,  -271,   139,
     140,  1434,   262,   142,   182,  -271,   171,   -97,   -96,   154,
     172,   172,  -271,   172,   191,  -271,  -271,  -271,  -271,  -271,
    -271,  -271,  -271,  -271,  -271,  -271,  -271,  -271,  1119,  -271,
    -271,  1119,   195,  -271,  -271,  1119,   540,   540,   540,   540,
     540,   873,   160,   169,   174,   175,   841,  -271,   176,  1119,
    1119,  -271,   196,  -271,   177,  -271,   178,   179,   180,  -271,
    -271,   189,   181,   190,   184,   540,   185,   841,   841,   186,
     188,  -271,   192,   193,   208,  -271,  -271,  -271,  -271,  -271,
     191,  -271,  1119,  -271,   841,   311,   312,   841,   841,   841,
    -271,  1119,  -271,   194,  -271,   841,   841,  -271,  -271,  -271,
     214,  -271,  -271,  -271,  1119,   215,  1119,   199,  -271
};

/* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
    -271,  -271,  -271,   285,    25,  -271,  -271,  -271,  -271,  -271,
     -41,  -271,  -271,  -270,  -271,  -271,  -271,  -271,   380,     0,
      15,    40,   -56,  -271,   117,   -79,  -271,  -271,    46,  -271
};

/* YYTABLE[YYPACT[STATE-NUM]].  What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule which
   number is the opposite.  If zero, do what YYDEFACT says.
   If YYTABLE_NINF, syntax error.  */
#define YYTABLE_NINF -125
static const yytype_int16 yytable[] =
{
      52,   128,    56,   189,   190,    52,     7,   321,   322,   323,
     324,    57,   380,   382,    58,    53,   196,   325,  -123,  -123,
      53,     7,    59,   198,   199,   200,   201,   202,   203,   204,
      60,   381,   383,    61,    52,    52,   240,   285,    52,   116,
      54,    62,   116,    52,   116,    54,    63,   116,   116,    85,
      87,   116,    64,    53,   155,   156,   117,    52,    53,   166,
      65,   167,    83,    90,   206,   299,  -120,   142,   300,    66,
     386,   387,    53,   388,    86,    88,   157,   158,    54,    67,
     159,   160,   143,    54,    31,    68,    32,    33,   203,   204,
      69,    52,   200,   201,   202,   203,   204,    54,    70,   141,
      71,    32,    33,    36,    52,    52,    53,   201,   202,   203,
     204,    72,    73,    74,    75,    37,   169,    76,    36,   180,
     182,    77,    78,    40,    79,    41,    80,   114,    81,    82,
      37,    54,    84,   125,   118,   119,   120,   121,   122,   123,
      41,   133,   140,   145,   181,   183,   124,   149,   188,   189,
     190,   191,   192,   193,   150,   151,   152,   153,   154,   326,
     194,   195,   196,  -123,   170,   171,   172,   197,   173,   198,
     199,   200,   201,   202,   203,   204,   174,   175,   135,   136,
     137,   138,   139,  -122,   205,   144,   176,   146,   147,   148,
     177,   178,   179,   207,   208,   209,   215,   216,   219,   162,
     222,   165,   217,   220,   223,   224,   225,   226,   227,   228,
     229,   116,   230,   234,   235,    52,   231,   232,   233,    52,
     236,   237,    52,   287,   238,   239,   288,   319,   241,   331,
      53,   339,   358,   334,    53,   345,   346,    53,   286,   290,
     347,   348,   349,   354,   332,   363,   355,   335,   356,   357,
     359,   188,   189,   190,   191,    54,   360,   361,   362,    54,
     364,   371,    54,   194,   195,   196,  -124,   372,   373,   376,
     377,   378,   198,   199,   200,   201,   202,   203,   204,   389,
     379,   382,   385,   394,   405,    52,    52,   289,   397,   291,
     292,   293,   294,   295,   296,   297,   298,   398,   410,   412,
      53,    53,   399,   400,   402,   406,   407,   408,   409,   411,
     352,   353,   413,   414,   417,   128,   418,   421,   425,   426,
     419,   420,   431,   434,   436,    54,    54,   438,   115,   351,
     396,   422,     0,   328,   330,     0,     0,   333,     0,     0,
     336,     0,     0,   337,     0,     0,   338,     0,   340,   342,
     343,     0,     0,     0,     0,     0,   188,   189,   190,   191,
     192,   193,     0,     0,     0,     0,     0,     0,   194,   195,
     196,    52,     0,     0,     0,   197,    52,   198,   199,   200,
     201,   202,   203,   204,     0,     0,    53,     0,     0,     0,
       0,    53,   301,     0,     0,     0,     0,    52,    52,     0,
       0,   401,     0,     0,     0,     0,     0,     0,     0,     0,
       0,    54,    53,    53,    52,     0,    54,    52,    52,    52,
     110,     0,   415,   416,     0,    52,    52,     0,     0,    53,
       0,     0,    53,    53,    53,     0,     0,    54,    54,   424,
      53,    53,   427,   428,   429,     0,     0,     0,   375,     0,
     432,   433,     0,     0,    54,     0,     0,    54,    54,    54,
       0,     0,     0,     0,     0,    54,    54,     0,     0,     0,
       0,     0,     0,     0,     0,   392,     0,     0,   393,     0,
       0,     0,     0,     0,     0,     0,   185,   186,   187,     0,
       0,     0,     0,     0,     0,     0,   403,   404,     0,     0,
     210,   211,   212,   213,   214,     0,     0,     0,     0,     0,
     186,     0,     0,     0,   186,     0,     0,     0,     0,     0,
     188,   189,   190,   191,   192,   193,     0,     0,     0,   423,
       0,     0,   194,   195,   196,     0,     0,     0,   430,   197,
     365,   198,   199,   200,   201,   202,   203,   204,     0,     0,
       0,   435,     0,   437,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   302,   303,
     304,   305,   306,   307,   308,   309,   310,   311,   312,   313,
     314,   315,   316,   317,   318,     0,     0,   320,     0,     0,
       1,     2,     3,     4,     0,     5,     6,     7,     0,     0,
       0,     0,     0,     0,     8,     9,    10,    11,    12,     0,
       0,    13,    14,    15,    16,    17,    18,     0,     0,     0,
      19,    20,    21,    22,    23,    24,    25,    26,    27,     0,
      28,    29,   188,   189,   190,   191,   192,   193,     0,     0,
       0,     0,     0,     0,   194,   195,   196,     0,     0,     0,
       0,   197,     0,   198,   199,   200,   201,   202,   203,   204,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,    30,     0,    31,     0,    32,    33,     0,
       0,     0,     0,     0,     0,    34,    35,     0,     0,     0,
       0,     0,     0,     0,    36,     0,     0,     0,     0,     0,
       0,   366,   367,   368,   369,   370,    37,     0,     0,     0,
       0,    38,    89,    39,    40,     0,    41,     1,     2,     3,
       4,     0,     5,     6,     7,     0,     0,     0,     0,     0,
       0,     8,     9,    10,    11,    12,     0,     0,    13,    14,
      15,    16,    17,    18,     0,   395,     0,    19,    20,    21,
      22,    23,    24,    25,    26,    27,     0,    28,    29,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
      30,     0,    31,     0,    32,    33,     0,     0,     0,     0,
       0,     0,    34,    35,     0,     0,     0,     0,     0,     0,
       0,    36,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,    37,     0,     0,     0,     0,    38,   168,
      39,    40,     0,    41,     1,     2,     3,     4,     0,     5,
       6,     7,     0,     0,     0,     0,     0,     0,     8,     9,
      10,    11,    12,     0,     0,    13,    14,    15,    16,    17,
      18,     0,     0,     0,    19,    20,    21,    22,    23,    24,
      25,    26,    27,     7,    28,    29,     0,     0,     0,     0,
       8,     9,    10,    11,    12,     0,     0,    13,    14,    15,
      16,    17,    18,     0,     0,     0,    19,    20,    21,    22,
      23,    24,    25,    26,    27,     0,    28,    29,     0,     0,
       0,     0,     0,     0,     0,     0,     0,    30,     0,    31,
       0,    32,    33,     0,     0,     0,     0,     0,     0,    34,
      35,     0,     0,     0,     0,     0,     0,     0,    36,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,    30,
      37,    31,     0,    32,    33,    38,     0,    39,    40,     0,
      41,    34,    35,     7,    92,    93,    94,    95,    96,    97,
      36,     0,     0,     0,     0,    98,    99,     0,     0,     0,
       0,     0,    37,     0,   100,   101,     0,     0,     0,     0,
      40,     0,    41,     0,     0,   129,     7,    92,    93,    94,
      95,    96,    97,     0,     0,     0,     0,     0,    98,    99,
       0,     0,     0,     0,     0,     0,     0,   100,   101,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   218,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   102,   103,    32,    33,     0,     0,     0,     0,     0,
       0,   104,   105,     0,     0,     0,     0,     0,     0,     0,
      36,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     106,     0,    37,   130,   102,   103,    32,    33,     0,     0,
     108,     0,    41,     0,   104,   105,     7,    92,    93,    94,
      95,    96,    97,    36,     0,     0,     0,     0,    98,    99,
       0,     0,     0,   106,     0,    37,   107,   100,   101,     0,
       0,     0,     0,   108,     0,    41,     0,     0,   221,     7,
      92,    93,    94,    95,    96,    97,     0,     0,     0,     0,
       0,    98,    99,     7,    92,    93,    94,    95,    96,    97,
     100,   101,     0,     0,     0,    98,    99,     0,     0,     0,
       0,     0,     0,     0,   100,   101,     0,     0,     0,     0,
       0,     0,     0,     0,   102,   103,    32,    33,     0,     0,
       0,     0,     0,     0,   104,   105,     0,     0,     0,     0,
       0,     0,     0,    36,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   106,     0,    37,   107,   102,   103,    32,
      33,     0,     0,   108,     0,    41,     0,   104,   105,     0,
       0,   102,   103,    32,    33,     0,    36,     0,     0,     0,
       0,   104,   105,     0,     0,     0,   106,     0,    37,   107,
      36,     0,     0,     0,     0,     0,   108,     0,    41,     0,
     106,     0,    37,   134,     0,     0,     0,     0,     0,     0,
     108,     0,    41,     7,    92,    93,    94,    95,    96,    97,
       0,     0,     0,     0,     0,    98,    99,     7,    92,    93,
      94,    95,    96,    97,   100,   101,     0,     0,     0,    98,
      99,     0,     0,     0,     0,     0,     0,     0,   100,   101,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       7,    92,    93,    94,    95,    96,    97,     0,     0,     0,
       0,     0,    98,    99,     7,    92,    93,    94,    95,    96,
      97,   100,   101,     0,     0,     0,    98,    99,     0,     0,
       0,   161,   103,    32,    33,   100,   101,     0,     0,     0,
       0,   104,   105,     0,     0,   164,   103,    32,    33,     0,
      36,     0,     0,     0,     0,   104,   105,     0,     0,     0,
     106,     0,    37,   107,    36,     0,     0,     0,     0,     0,
     108,     0,    41,     0,   106,     0,    37,   107,   102,   184,
      32,    33,     0,     0,   108,     0,    41,     0,   104,   105,
       0,     0,   102,   329,    32,    33,     0,    36,     0,     0,
       0,     0,   104,   105,     0,     0,     0,   106,     0,    37,
     107,    36,     0,     0,     0,     0,     0,   108,     0,    41,
       0,   106,     0,    37,   107,     0,     0,     0,     0,     0,
       0,   108,     0,    41,     7,    92,    93,    94,    95,    96,
      97,     0,     0,     0,     0,     0,    98,    99,     0,     0,
       0,     0,     0,     0,     0,   100,   101,   242,   243,   244,
     245,   246,   247,   248,   249,   250,   251,   252,   253,   254,
     255,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   102,   374,    32,    33,     0,     0,     0,     0,
       0,     0,   104,   105,     0,     0,     0,     0,     0,     0,
       0,    36,     0,     0,     0,     0,     0,   350,     0,     0,
       0,   106,     0,    37,   107,     0,     0,     0,     0,     0,
       0,   108,     0,    41,   242,   243,   244,   245,   246,   247,
     248,   249,   250,   251,   252,   253,   254,   255,   256,   257,
     258,   259,   260,   261,   262,   263,   264,   265,   266,   267,
     268,   269,   270,   271,   272,   273,   274,   275,   276,   277,
     278,   279,   280,   281,   282
};

static const yytype_int16 yycheck[] =
{
       0,    57,   126,    93,    94,     5,    10,   100,   101,   102,
     103,   127,   109,   109,   126,     0,   106,   110,   110,   110,
       5,    10,   127,   113,   114,   115,   116,   117,   118,   119,
       5,   128,   128,   127,    34,    35,   128,   128,    38,   112,
       0,   127,   112,    43,   112,     5,   127,   112,   112,    34,
      35,   112,   127,    38,    88,    89,   129,    57,    43,   129,
     127,   129,   124,    38,   129,   129,   129,    67,   129,   127,
     340,   341,    57,   343,    34,    35,    88,    89,    38,   127,
      88,    89,    67,    43,    88,   127,    90,    91,   118,   119,
     127,    91,   115,   116,   117,   118,   119,    57,   127,    88,
     127,    90,    91,   107,   104,   105,    91,   116,   117,   118,
     119,   127,   127,   127,   127,   119,    91,   127,   107,   104,
     105,   127,   127,   127,   127,   129,   127,     0,   127,   127,
     119,    91,   127,   126,    98,    99,   100,   101,   102,   103,
     129,     9,   128,    88,   104,   105,   110,   128,    92,    93,
      94,    95,    96,    97,   128,   128,   128,   128,   128,   215,
     104,   105,   106,   110,   127,   127,   127,   111,   127,   113,
     114,   115,   116,   117,   118,   119,   127,   127,    61,    62,
      63,    64,    65,   110,   128,    68,   127,    70,    71,    72,
     127,   127,   127,   110,    90,    90,   109,   126,   128,    82,
     128,    84,   127,   127,   109,   128,   128,   109,   128,   128,
     109,   112,   109,   128,   128,   215,   109,   109,   109,   219,
     128,   128,   222,    90,   128,   128,    90,    90,   128,   127,
     215,    88,   109,   127,   219,    89,    89,   222,   128,   128,
      89,    89,    89,   128,   219,    90,   128,   222,   128,   128,
     128,    92,    93,    94,    95,   215,   128,   109,   109,   219,
      90,   126,   222,   104,   105,   106,   110,   128,   128,     7,
     128,    89,   113,   114,   115,   116,   117,   118,   119,    88,
     109,   109,   128,    88,    88,   285,   286,   170,   128,   172,
     173,   174,   175,   176,   177,   178,   179,   128,   109,   109,
     285,   286,   128,   128,   128,   128,   128,   128,   128,   128,
     285,   286,   128,   128,   128,   371,   128,   109,     7,     7,
     128,   128,   128,   109,   109,   285,   286,   128,    43,   283,
     371,   410,    -1,   216,   217,    -1,    -1,   220,    -1,    -1,
     223,    -1,    -1,   226,    -1,    -1,   229,    -1,   231,   232,
     233,    -1,    -1,    -1,    -1,    -1,    92,    93,    94,    95,
      96,    97,    -1,    -1,    -1,    -1,    -1,    -1,   104,   105,
     106,   371,    -1,    -1,    -1,   111,   376,   113,   114,   115,
     116,   117,   118,   119,    -1,    -1,   371,    -1,    -1,    -1,
      -1,   376,   128,    -1,    -1,    -1,    -1,   397,   398,    -1,
      -1,   376,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   371,   397,   398,   414,    -1,   376,   417,   418,   419,
      40,    -1,   397,   398,    -1,   425,   426,    -1,    -1,   414,
      -1,    -1,   417,   418,   419,    -1,    -1,   397,   398,   414,
     425,   426,   417,   418,   419,    -1,    -1,    -1,   331,    -1,
     425,   426,    -1,    -1,   414,    -1,    -1,   417,   418,   419,
      -1,    -1,    -1,    -1,    -1,   425,   426,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   358,    -1,    -1,   361,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   106,   107,   108,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   379,   380,    -1,    -1,
     120,   121,   122,   123,   124,    -1,    -1,    -1,    -1,    -1,
     130,    -1,    -1,    -1,   134,    -1,    -1,    -1,    -1,    -1,
      92,    93,    94,    95,    96,    97,    -1,    -1,    -1,   412,
      -1,    -1,   104,   105,   106,    -1,    -1,    -1,   421,   111,
     112,   113,   114,   115,   116,   117,   118,   119,    -1,    -1,
      -1,   434,    -1,   436,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   188,   189,
     190,   191,   192,   193,   194,   195,   196,   197,   198,   199,
     200,   201,   202,   203,   204,    -1,    -1,   207,    -1,    -1,
       3,     4,     5,     6,    -1,     8,     9,    10,    -1,    -1,
      -1,    -1,    -1,    -1,    17,    18,    19,    20,    21,    -1,
      -1,    24,    25,    26,    27,    28,    29,    -1,    -1,    -1,
      33,    34,    35,    36,    37,    38,    39,    40,    41,    -1,
      43,    44,    92,    93,    94,    95,    96,    97,    -1,    -1,
      -1,    -1,    -1,    -1,   104,   105,   106,    -1,    -1,    -1,
      -1,   111,    -1,   113,   114,   115,   116,   117,   118,   119,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    86,    -1,    88,    -1,    90,    91,    -1,
      -1,    -1,    -1,    -1,    -1,    98,    99,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   107,    -1,    -1,    -1,    -1,    -1,
      -1,   321,   322,   323,   324,   325,   119,    -1,    -1,    -1,
      -1,   124,   125,   126,   127,    -1,   129,     3,     4,     5,
       6,    -1,     8,     9,    10,    -1,    -1,    -1,    -1,    -1,
      -1,    17,    18,    19,    20,    21,    -1,    -1,    24,    25,
      26,    27,    28,    29,    -1,   365,    -1,    33,    34,    35,
      36,    37,    38,    39,    40,    41,    -1,    43,    44,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      86,    -1,    88,    -1,    90,    91,    -1,    -1,    -1,    -1,
      -1,    -1,    98,    99,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   107,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   119,    -1,    -1,    -1,    -1,   124,   125,
     126,   127,    -1,   129,     3,     4,     5,     6,    -1,     8,
       9,    10,    -1,    -1,    -1,    -1,    -1,    -1,    17,    18,
      19,    20,    21,    -1,    -1,    24,    25,    26,    27,    28,
      29,    -1,    -1,    -1,    33,    34,    35,    36,    37,    38,
      39,    40,    41,    10,    43,    44,    -1,    -1,    -1,    -1,
      17,    18,    19,    20,    21,    -1,    -1,    24,    25,    26,
      27,    28,    29,    -1,    -1,    -1,    33,    34,    35,    36,
      37,    38,    39,    40,    41,    -1,    43,    44,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    86,    -1,    88,
      -1,    90,    91,    -1,    -1,    -1,    -1,    -1,    -1,    98,
      99,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   107,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    86,
     119,    88,    -1,    90,    91,   124,    -1,   126,   127,    -1,
     129,    98,    99,    10,    11,    12,    13,    14,    15,    16,
     107,    -1,    -1,    -1,    -1,    22,    23,    -1,    -1,    -1,
      -1,    -1,   119,    -1,    31,    32,    -1,    -1,    -1,    -1,
     127,    -1,   129,    -1,    -1,    42,    10,    11,    12,    13,
      14,    15,    16,    -1,    -1,    -1,    -1,    -1,    22,    23,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    31,    32,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    42,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    88,    89,    90,    91,    -1,    -1,    -1,    -1,    -1,
      -1,    98,    99,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     107,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     117,    -1,   119,   120,    88,    89,    90,    91,    -1,    -1,
     127,    -1,   129,    -1,    98,    99,    10,    11,    12,    13,
      14,    15,    16,   107,    -1,    -1,    -1,    -1,    22,    23,
      -1,    -1,    -1,   117,    -1,   119,   120,    31,    32,    -1,
      -1,    -1,    -1,   127,    -1,   129,    -1,    -1,    42,    10,
      11,    12,    13,    14,    15,    16,    -1,    -1,    -1,    -1,
      -1,    22,    23,    10,    11,    12,    13,    14,    15,    16,
      31,    32,    -1,    -1,    -1,    22,    23,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    31,    32,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    88,    89,    90,    91,    -1,    -1,
      -1,    -1,    -1,    -1,    98,    99,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   107,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   117,    -1,   119,   120,    88,    89,    90,
      91,    -1,    -1,   127,    -1,   129,    -1,    98,    99,    -1,
      -1,    88,    89,    90,    91,    -1,   107,    -1,    -1,    -1,
      -1,    98,    99,    -1,    -1,    -1,   117,    -1,   119,   120,
     107,    -1,    -1,    -1,    -1,    -1,   127,    -1,   129,    -1,
     117,    -1,   119,   120,    -1,    -1,    -1,    -1,    -1,    -1,
     127,    -1,   129,    10,    11,    12,    13,    14,    15,    16,
      -1,    -1,    -1,    -1,    -1,    22,    23,    10,    11,    12,
      13,    14,    15,    16,    31,    32,    -1,    -1,    -1,    22,
      23,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    31,    32,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      10,    11,    12,    13,    14,    15,    16,    -1,    -1,    -1,
      -1,    -1,    22,    23,    10,    11,    12,    13,    14,    15,
      16,    31,    32,    -1,    -1,    -1,    22,    23,    -1,    -1,
      -1,    88,    89,    90,    91,    31,    32,    -1,    -1,    -1,
      -1,    98,    99,    -1,    -1,    88,    89,    90,    91,    -1,
     107,    -1,    -1,    -1,    -1,    98,    99,    -1,    -1,    -1,
     117,    -1,   119,   120,   107,    -1,    -1,    -1,    -1,    -1,
     127,    -1,   129,    -1,   117,    -1,   119,   120,    88,    89,
      90,    91,    -1,    -1,   127,    -1,   129,    -1,    98,    99,
      -1,    -1,    88,    89,    90,    91,    -1,   107,    -1,    -1,
      -1,    -1,    98,    99,    -1,    -1,    -1,   117,    -1,   119,
     120,   107,    -1,    -1,    -1,    -1,    -1,   127,    -1,   129,
      -1,   117,    -1,   119,   120,    -1,    -1,    -1,    -1,    -1,
      -1,   127,    -1,   129,    10,    11,    12,    13,    14,    15,
      16,    -1,    -1,    -1,    -1,    -1,    22,    23,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    31,    32,    45,    46,    47,
      48,    49,    50,    51,    52,    53,    54,    55,    56,    57,
      58,    59,    60,    61,    62,    63,    64,    65,    66,    67,
      68,    69,    70,    71,    72,    73,    74,    75,    76,    77,
      78,    79,    80,    81,    82,    83,    84,    85,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    88,    89,    90,    91,    -1,    -1,    -1,    -1,
      -1,    -1,    98,    99,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   107,    -1,    -1,    -1,    -1,    -1,   125,    -1,    -1,
      -1,   117,    -1,   119,   120,    -1,    -1,    -1,    -1,    -1,
      -1,   127,    -1,   129,    45,    46,    47,    48,    49,    50,
      51,    52,    53,    54,    55,    56,    57,    58,    59,    60,
      61,    62,    63,    64,    65,    66,    67,    68,    69,    70,
      71,    72,    73,    74,    75,    76,    77,    78,    79,    80,
      81,    82,    83,    84,    85
};

/* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
   symbol of state STATE-NUM.  */
static const yytype_uint8 yystos[] =
{
       0,     3,     4,     5,     6,     8,     9,    10,    17,    18,
      19,    20,    21,    24,    25,    26,    27,    28,    29,    33,
      34,    35,    36,    37,    38,    39,    40,    41,    43,    44,
      86,    88,    90,    91,    98,    99,   107,   119,   124,   126,
     127,   129,   131,   132,   133,   134,   137,   139,   141,   142,
     145,   147,   149,   150,   151,   152,   126,   127,   126,   127,
     134,   127,   127,   127,   127,   127,   127,   127,   127,   127,
     127,   127,   127,   127,   127,   127,   127,   127,   127,   127,
     127,   127,   127,   124,   127,   150,   151,   150,   151,   125,
     134,   136,    11,    12,    13,    14,    15,    16,    22,    23,
      31,    32,    88,    89,    98,    99,   117,   120,   127,   146,
     148,   149,   150,   151,     0,   133,   112,   129,    98,    99,
     100,   101,   102,   103,   110,   126,   135,   140,   152,    42,
     120,   148,   154,     9,   120,   154,   154,   154,   154,   154,
     128,    88,   149,   150,   154,    88,   154,   154,   154,   128,
     128,   128,   128,   128,   128,    88,    89,    88,    89,    88,
      89,    88,   154,   153,    88,   154,   129,   129,   125,   134,
     127,   127,   127,   127,   127,   127,   127,   127,   127,   127,
     150,   151,   150,   151,    89,   148,   148,   148,    92,    93,
      94,    95,    96,    97,   104,   105,   106,   111,   113,   114,
     115,   116,   117,   118,   119,   128,   129,   110,    90,    90,
     148,   148,   148,   148,   148,   109,   126,   127,    42,   128,
     127,    42,   128,   109,   128,   128,   109,   128,   128,   109,
     109,   109,   109,   109,   128,   128,   128,   128,   128,   128,
     128,   128,    45,    46,    47,    48,    49,    50,    51,    52,
      53,    54,    55,    56,    57,    58,    59,    60,    61,    62,
      63,    64,    65,    66,    67,    68,    69,    70,    71,    72,
      73,    74,    75,    76,    77,    78,    79,    80,    81,    82,
      83,    84,    85,   157,   158,   128,   128,    90,    90,   154,
     128,   154,   154,   154,   154,   154,   154,   154,   154,   129,
     129,   128,   148,   148,   148,   148,   148,   148,   148,   148,
     148,   148,   148,   148,   148,   148,   148,   148,   148,    90,
     148,   100,   101,   102,   103,   110,   152,   138,   154,    89,
     154,   127,   134,   154,   127,   134,   154,   154,   154,    88,
     154,   144,   154,   154,   159,    89,    89,    89,    89,    89,
     125,   158,   134,   134,   128,   128,   128,   128,   109,   128,
     128,   109,   109,    90,    90,   112,   148,   148,   148,   148,
     148,   126,   128,   128,    89,   154,     7,   128,    89,   109,
     109,   128,   109,   128,   143,   128,   143,   143,   143,    88,
     155,   156,   154,   154,    88,   148,   140,   128,   128,   128,
     128,   134,   128,   154,   154,    88,   128,   128,   128,   128,
     109,   128,   109,   128,   128,   134,   134,   128,   128,   128,
     128,   109,   155,   154,   134,     7,     7,   134,   134,   134,
     154,   128,   134,   134,   109,   154,   109,   154,   128
};

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		(-2)
#define YYEOF		0

#define YYACCEPT	goto yyacceptlab
#define YYABORT		goto yyabortlab
#define YYERROR		goto yyerrorlab


/* Like YYERROR except do call yyerror.  This remains here temporarily
   to ease the transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */

#define YYFAIL		goto yyerrlab

#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)					\
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    {								\
      yychar = (Token);						\
      yylval = (Value);						\
      yytoken = YYTRANSLATE (yychar);				\
      YYPOPSTACK (1);						\
      goto yybackup;						\
    }								\
  else								\
    {								\
      yyerror (YY_("syntax error: cannot back up")); \
      YYERROR;							\
    }								\
while (YYID (0))


#define YYTERROR	1
#define YYERRCODE	256


/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */

#define YYRHSLOC(Rhs, K) ((Rhs)[K])
#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)				\
    do									\
      if (YYID (N))                                                    \
	{								\
	  (Current).first_line   = YYRHSLOC (Rhs, 1).first_line;	\
	  (Current).first_column = YYRHSLOC (Rhs, 1).first_column;	\
	  (Current).last_line    = YYRHSLOC (Rhs, N).last_line;		\
	  (Current).last_column  = YYRHSLOC (Rhs, N).last_column;	\
	}								\
      else								\
	{								\
	  (Current).first_line   = (Current).last_line   =		\
	    YYRHSLOC (Rhs, 0).last_line;				\
	  (Current).first_column = (Current).last_column =		\
	    YYRHSLOC (Rhs, 0).last_column;				\
	}								\
    while (YYID (0))
#endif


/* YY_LOCATION_PRINT -- Print the location on the stream.
   This macro was not mandated originally: define only if we know
   we won't break user code: when these are the locations we know.  */

#ifndef YY_LOCATION_PRINT
# if defined YYLTYPE_IS_TRIVIAL && YYLTYPE_IS_TRIVIAL
#  define YY_LOCATION_PRINT(File, Loc)			\
     fprintf (File, "%d.%d-%d.%d",			\
	      (Loc).first_line, (Loc).first_column,	\
	      (Loc).last_line,  (Loc).last_column)
# else
#  define YY_LOCATION_PRINT(File, Loc) ((void) 0)
# endif
#endif


/* YYLEX -- calling `yylex' with the right arguments.  */

#ifdef YYLEX_PARAM
# define YYLEX yylex (YYLEX_PARAM)
#else
# define YYLEX yylex ()
#endif

/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)			\
do {						\
  if (yydebug)					\
    YYFPRINTF Args;				\
} while (YYID (0))

# define YY_SYMBOL_PRINT(Title, Type, Value, Location)			  \
do {									  \
  if (yydebug)								  \
    {									  \
      YYFPRINTF (stderr, "%s ", Title);					  \
      yy_symbol_print (stderr,						  \
		  Type, Value); \
      YYFPRINTF (stderr, "\n");						  \
    }									  \
} while (YYID (0))


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

/*ARGSUSED*/
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_symbol_value_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
#else
static void
yy_symbol_value_print (yyoutput, yytype, yyvaluep)
    FILE *yyoutput;
    int yytype;
    YYSTYPE const * const yyvaluep;
#endif
{
  if (!yyvaluep)
    return;
# ifdef YYPRINT
  if (yytype < YYNTOKENS)
    YYPRINT (yyoutput, yytoknum[yytype], *yyvaluep);
# else
  YYUSE (yyoutput);
# endif
  switch (yytype)
    {
      default:
	break;
    }
}


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_symbol_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
#else
static void
yy_symbol_print (yyoutput, yytype, yyvaluep)
    FILE *yyoutput;
    int yytype;
    YYSTYPE const * const yyvaluep;
#endif
{
  if (yytype < YYNTOKENS)
    YYFPRINTF (yyoutput, "token %s (", yytname[yytype]);
  else
    YYFPRINTF (yyoutput, "nterm %s (", yytname[yytype]);

  yy_symbol_value_print (yyoutput, yytype, yyvaluep);
  YYFPRINTF (yyoutput, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_stack_print (yytype_int16 *bottom, yytype_int16 *top)
#else
static void
yy_stack_print (bottom, top)
    yytype_int16 *bottom;
    yytype_int16 *top;
#endif
{
  YYFPRINTF (stderr, "Stack now");
  for (; bottom <= top; ++bottom)
    YYFPRINTF (stderr, " %d", *bottom);
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)				\
do {								\
  if (yydebug)							\
    yy_stack_print ((Bottom), (Top));				\
} while (YYID (0))


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_reduce_print (YYSTYPE *yyvsp, int yyrule)
#else
static void
yy_reduce_print (yyvsp, yyrule)
    YYSTYPE *yyvsp;
    int yyrule;
#endif
{
  int yynrhs = yyr2[yyrule];
  int yyi;
  unsigned long int yylno = yyrline[yyrule];
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %lu):\n",
	     yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      fprintf (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr, yyrhs[yyprhs[yyrule] + yyi],
		       &(yyvsp[(yyi + 1) - (yynrhs)])
		       		       );
      fprintf (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)		\
do {					\
  if (yydebug)				\
    yy_reduce_print (yyvsp, Rule); \
} while (YYID (0))

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
# define YY_SYMBOL_PRINT(Title, Type, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef	YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif



#if YYERROR_VERBOSE

# ifndef yystrlen
#  if defined __GLIBC__ && defined _STRING_H
#   define yystrlen strlen
#  else
/* Return the length of YYSTR.  */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static YYSIZE_T
yystrlen (const char *yystr)
#else
static YYSIZE_T
yystrlen (yystr)
    const char *yystr;
#endif
{
  YYSIZE_T yylen;
  for (yylen = 0; yystr[yylen]; yylen++)
    continue;
  return yylen;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined __GLIBC__ && defined _STRING_H && defined _GNU_SOURCE
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static char *
yystpcpy (char *yydest, const char *yysrc)
#else
static char *
yystpcpy (yydest, yysrc)
    char *yydest;
    const char *yysrc;
#endif
{
  char *yyd = yydest;
  const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif

# ifndef yytnamerr
/* Copy to YYRES the contents of YYSTR after stripping away unnecessary
   quotes and backslashes, so that it's suitable for yyerror.  The
   heuristic is that double-quoting is unnecessary unless the string
   contains an apostrophe, a comma, or backslash (other than
   backslash-backslash).  YYSTR is taken from yytname.  If YYRES is
   null, do not copy; instead, return the length of what the result
   would have been.  */
static YYSIZE_T
yytnamerr (char *yyres, const char *yystr)
{
  if (*yystr == '"')
    {
      YYSIZE_T yyn = 0;
      char const *yyp = yystr;

      for (;;)
	switch (*++yyp)
	  {
	  case '\'':
	  case ',':
	    goto do_not_strip_quotes;

	  case '\\':
	    if (*++yyp != '\\')
	      goto do_not_strip_quotes;
	    /* Fall through.  */
	  default:
	    if (yyres)
	      yyres[yyn] = *yyp;
	    yyn++;
	    break;

	  case '"':
	    if (yyres)
	      yyres[yyn] = '\0';
	    return yyn;
	  }
    do_not_strip_quotes: ;
    }

  if (! yyres)
    return yystrlen (yystr);

  return yystpcpy (yyres, yystr) - yyres;
}
# endif

/* Copy into YYRESULT an error message about the unexpected token
   YYCHAR while in state YYSTATE.  Return the number of bytes copied,
   including the terminating null byte.  If YYRESULT is null, do not
   copy anything; just return the number of bytes that would be
   copied.  As a special case, return 0 if an ordinary "syntax error"
   message will do.  Return YYSIZE_MAXIMUM if overflow occurs during
   size calculation.  */
static YYSIZE_T
yysyntax_error (char *yyresult, int yystate, int yychar)
{
  int yyn = yypact[yystate];

  if (! (YYPACT_NINF < yyn && yyn <= YYLAST))
    return 0;
  else
    {
      int yytype = YYTRANSLATE (yychar);
      YYSIZE_T yysize0 = yytnamerr (0, yytname[yytype]);
      YYSIZE_T yysize = yysize0;
      YYSIZE_T yysize1;
      int yysize_overflow = 0;
      enum { YYERROR_VERBOSE_ARGS_MAXIMUM = 5 };
      char const *yyarg[YYERROR_VERBOSE_ARGS_MAXIMUM];
      int yyx;

# if 0
      /* This is so xgettext sees the translatable formats that are
	 constructed on the fly.  */
      YY_("syntax error, unexpected %s");
      YY_("syntax error, unexpected %s, expecting %s");
      YY_("syntax error, unexpected %s, expecting %s or %s");
      YY_("syntax error, unexpected %s, expecting %s or %s or %s");
      YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s");
# endif
      char *yyfmt;
      char const *yyf;
      static char const yyunexpected[] = "syntax error, unexpected %s";
      static char const yyexpecting[] = ", expecting %s";
      static char const yyor[] = " or %s";
      char yyformat[sizeof yyunexpected
		    + sizeof yyexpecting - 1
		    + ((YYERROR_VERBOSE_ARGS_MAXIMUM - 2)
		       * (sizeof yyor - 1))];
      char const *yyprefix = yyexpecting;

      /* Start YYX at -YYN if negative to avoid negative indexes in
	 YYCHECK.  */
      int yyxbegin = yyn < 0 ? -yyn : 0;

      /* Stay within bounds of both yycheck and yytname.  */
      int yychecklim = YYLAST - yyn + 1;
      int yyxend = yychecklim < YYNTOKENS ? yychecklim : YYNTOKENS;
      int yycount = 1;

      yyarg[0] = yytname[yytype];
      yyfmt = yystpcpy (yyformat, yyunexpected);

      for (yyx = yyxbegin; yyx < yyxend; ++yyx)
	if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR)
	  {
	    if (yycount == YYERROR_VERBOSE_ARGS_MAXIMUM)
	      {
		yycount = 1;
		yysize = yysize0;
		yyformat[sizeof yyunexpected - 1] = '\0';
		break;
	      }
	    yyarg[yycount++] = yytname[yyx];
	    yysize1 = yysize + yytnamerr (0, yytname[yyx]);
	    yysize_overflow |= (yysize1 < yysize);
	    yysize = yysize1;
	    yyfmt = yystpcpy (yyfmt, yyprefix);
	    yyprefix = yyor;
	  }

      yyf = YY_(yyformat);
      yysize1 = yysize + yystrlen (yyf);
      yysize_overflow |= (yysize1 < yysize);
      yysize = yysize1;

      if (yysize_overflow)
	return YYSIZE_MAXIMUM;

      if (yyresult)
	{
	  /* Avoid sprintf, as that infringes on the user's name space.
	     Don't have undefined behavior even if the translation
	     produced a string with the wrong number of "%s"s.  */
	  char *yyp = yyresult;
	  int yyi = 0;
	  while ((*yyp = *yyf) != '\0')
	    {
	      if (*yyp == '%' && yyf[1] == 's' && yyi < yycount)
		{
		  yyp += yytnamerr (yyp, yyarg[yyi++]);
		  yyf += 2;
		}
	      else
		{
		  yyp++;
		  yyf++;
		}
	    }
	}
      return yysize;
    }
}
#endif /* YYERROR_VERBOSE */


/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

/*ARGSUSED*/
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yydestruct (const char *yymsg, int yytype, YYSTYPE *yyvaluep)
#else
static void
yydestruct (yymsg, yytype, yyvaluep)
    const char *yymsg;
    int yytype;
    YYSTYPE *yyvaluep;
#endif
{
  YYUSE (yyvaluep);

  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yytype, yyvaluep, yylocationp);

  switch (yytype)
    {

      default:
	break;
    }
}


/* Prevent warnings from -Wmissing-prototypes.  */

#ifdef YYPARSE_PARAM
#if defined __STDC__ || defined __cplusplus
int yyparse (void *YYPARSE_PARAM);
#else
int yyparse ();
#endif
#else /* ! YYPARSE_PARAM */
#if defined __STDC__ || defined __cplusplus
int yyparse (void);
#else
int yyparse ();
#endif
#endif /* ! YYPARSE_PARAM */



/* The look-ahead symbol.  */
int yychar;

/* The semantic value of the look-ahead symbol.  */
YYSTYPE yylval;

/* Number of syntax errors so far.  */
int yynerrs;



/*----------.
| yyparse.  |
`----------*/

#ifdef YYPARSE_PARAM
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
int
yyparse (void *YYPARSE_PARAM)
#else
int
yyparse (YYPARSE_PARAM)
    void *YYPARSE_PARAM;
#endif
#else /* ! YYPARSE_PARAM */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
int
yyparse (void)
#else
int
yyparse ()

#endif
#endif
{
  
  int yystate;
  int yyn;
  int yyresult;
  /* Number of tokens to shift before error messages enabled.  */
  int yyerrstatus;
  /* Look-ahead token as an internal (translated) token number.  */
  int yytoken = 0;
#if YYERROR_VERBOSE
  /* Buffer for error messages, and its allocated size.  */
  char yymsgbuf[128];
  char *yymsg = yymsgbuf;
  YYSIZE_T yymsg_alloc = sizeof yymsgbuf;
#endif

  /* Three stacks and their tools:
     `yyss': related to states,
     `yyvs': related to semantic values,
     `yyls': related to locations.

     Refer to the stacks thru separate pointers, to allow yyoverflow
     to reallocate them elsewhere.  */

  /* The state stack.  */
  yytype_int16 yyssa[YYINITDEPTH];
  yytype_int16 *yyss = yyssa;
  yytype_int16 *yyssp;

  /* The semantic value stack.  */
  YYSTYPE yyvsa[YYINITDEPTH];
  YYSTYPE *yyvs = yyvsa;
  YYSTYPE *yyvsp;



#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N))

  YYSIZE_T yystacksize = YYINITDEPTH;

  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;


  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY;		/* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */

  yyssp = yyss;
  yyvsp = yyvs;

  goto yysetstate;

/*------------------------------------------------------------.
| yynewstate -- Push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
 yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;

 yysetstate:
  *yyssp = yystate;

  if (yyss + yystacksize - 1 <= yyssp)
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYSIZE_T yysize = yyssp - yyss + 1;

#ifdef yyoverflow
      {
	/* Give user a chance to reallocate the stack.  Use copies of
	   these so that the &'s don't force the real ones into
	   memory.  */
	YYSTYPE *yyvs1 = yyvs;
	yytype_int16 *yyss1 = yyss;


	/* Each stack pointer address is followed by the size of the
	   data in use in that stack, in bytes.  This used to be a
	   conditional around just the two extra args, but that might
	   be undefined if yyoverflow is a macro.  */
	yyoverflow (YY_("memory exhausted"),
		    &yyss1, yysize * sizeof (*yyssp),
		    &yyvs1, yysize * sizeof (*yyvsp),

		    &yystacksize);

	yyss = yyss1;
	yyvs = yyvs1;
      }
#else /* no yyoverflow */
# ifndef YYSTACK_RELOCATE
      goto yyexhaustedlab;
# else
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
	goto yyexhaustedlab;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
	yystacksize = YYMAXDEPTH;

      {
	yytype_int16 *yyss1 = yyss;
	union yyalloc *yyptr =
	  (union yyalloc *) YYSTACK_ALLOC (YYSTACK_BYTES (yystacksize));
	if (! yyptr)
	  goto yyexhaustedlab;
	YYSTACK_RELOCATE (yyss);
	YYSTACK_RELOCATE (yyvs);

#  undef YYSTACK_RELOCATE
	if (yyss1 != yyssa)
	  YYSTACK_FREE (yyss1);
      }
# endif
#endif /* no yyoverflow */

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;


      YYDPRINTF ((stderr, "Stack size increased to %lu\n",
		  (unsigned long int) yystacksize));

      if (yyss + yystacksize - 1 <= yyssp)
	YYABORT;
    }

  YYDPRINTF ((stderr, "Entering state %d\n", yystate));

  goto yybackup;

/*-----------.
| yybackup.  |
`-----------*/
yybackup:

  /* Do appropriate processing given the current state.  Read a
     look-ahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to look-ahead token.  */
  yyn = yypact[yystate];
  if (yyn == YYPACT_NINF)
    goto yydefault;

  /* Not known => get a look-ahead token if don't already have one.  */

  /* YYCHAR is either YYEMPTY or YYEOF or a valid look-ahead symbol.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = YYLEX;
    }

  if (yychar <= YYEOF)
    {
      yychar = yytoken = YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yyn == 0 || yyn == YYTABLE_NINF)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the look-ahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);

  /* Discard the shifted token unless it is eof.  */
  if (yychar != YYEOF)
    yychar = YYEMPTY;

  yystate = yyn;
  *++yyvsp = yylval;

  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- Do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     `$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
        case 2:
#line 165 "swf4compiler.y"
    { *((Buffer *)buffer) = (yyvsp[(1) - (1)].action); }
    break;

  case 4:
#line 172 "swf4compiler.y"
    { bufferConcat((yyvsp[(1) - (2)].action), (yyvsp[(2) - (2)].action)); }
    break;

  case 6:
#line 180 "swf4compiler.y"
    { (yyval.action) = NULL; }
    break;

  case 7:
#line 181 "swf4compiler.y"
    { (yyval.action) = (yyvsp[(2) - (3)].action); }
    break;

  case 8:
#line 182 "swf4compiler.y"
    { (yyval.action) = NULL; }
    break;

  case 15:
#line 192 "swf4compiler.y"
    { bufferConcat((yyvsp[(1) - (3)].action), (yyvsp[(3) - (3)].action)); }
    break;

  case 16:
#line 196 "swf4compiler.y"
    { (yyval.action) = NULL; }
    break;

  case 18:
#line 199 "swf4compiler.y"
    { bufferConcat((yyvsp[(1) - (2)].action), (yyvsp[(2) - (2)].action)); }
    break;

  case 19:
#line 206 "swf4compiler.y"
    { (yyval.action) = newBuffer();
		  bufferWriteU8((yyval.action), SWFACTION_WAITFORFRAME);
		  bufferWriteS16((yyval.action), 3);
		  bufferWriteS16((yyval.action), atoi((yyvsp[(5) - (10)].str)));
		  free((yyvsp[(5) - (10)].str));
		  bufferWriteU8((yyval.action), 1);		/* if not loaded, jump to.. */
		  bufferWriteU8((yyval.action), SWFACTION_JUMP);
		  bufferWriteS16((yyval.action), 2);
		  bufferWriteS16((yyval.action), bufferLength((yyvsp[(10) - (10)].action))+5);
		  bufferConcat((yyval.action), (yyvsp[(10) - (10)].action));			  /* ..here */
		  bufferWriteU8((yyval.action), SWFACTION_JUMP);
		  bufferWriteS16((yyval.action), 2);
		  bufferWriteS16((yyval.action), bufferLength((yyvsp[(8) - (10)].action)));
		  bufferConcat((yyval.action), (yyvsp[(8) - (10)].action)); }
    break;

  case 20:
#line 222 "swf4compiler.y"
    { (yyval.action) = newBuffer();
		  bufferWriteU8((yyval.action), SWFACTION_WAITFORFRAME);
		  bufferWriteS16((yyval.action), 3);
		  bufferWriteS16((yyval.action), atoi((yyvsp[(5) - (8)].str)));
		  free((yyvsp[(5) - (8)].str));
		  bufferWriteU8((yyval.action), 1);		/* if not loaded, jump to.. */
		  bufferWriteU8((yyval.action), SWFACTION_JUMP);
		  bufferWriteS16((yyval.action), 2);
		  bufferWriteS16((yyval.action), 5);
		  bufferWriteU8((yyval.action), SWFACTION_JUMP);	  /* ..here */
		  bufferWriteS16((yyval.action), 2);
		  bufferWriteS16((yyval.action), bufferLength((yyvsp[(8) - (8)].action)));	  /* ..and then out */
		  bufferConcat((yyval.action), (yyvsp[(8) - (8)].action)); }
    break;

  case 21:
#line 238 "swf4compiler.y"
    { (yyval.action) = newBuffer();
		  bufferWriteU8((yyval.action), SWFACTION_WAITFORFRAME);
		  bufferWriteS16((yyval.action), 3);
		  bufferWriteS16((yyval.action), atoi((yyvsp[(6) - (9)].str)));
		  free((yyvsp[(6) - (9)].str));
		  bufferWriteU8((yyval.action), 1);		/* if not loaded, jump to.. */
		  bufferWriteU8((yyval.action), SWFACTION_JUMP);
		  bufferWriteS16((yyval.action), 2);
		  bufferWriteS16((yyval.action), bufferLength((yyvsp[(9) - (9)].action)));
		  bufferConcat((yyval.action), (yyvsp[(9) - (9)].action)); }
    break;

  case 22:
#line 250 "swf4compiler.y"
    { (yyval.action) = (yyvsp[(5) - (10)].action);
		  bufferWriteU8((yyval.action), SWFACTION_WAITFORFRAME2);
		  bufferWriteS16((yyval.action), 1);
		  bufferWriteU8((yyval.action), 1);		/* if not loaded, jump to.. */
		  bufferWriteU8((yyval.action), SWFACTION_JUMP);
		  bufferWriteS16((yyval.action), 2);
		  bufferWriteS16((yyval.action), bufferLength((yyvsp[(10) - (10)].action))+5);
		  bufferConcat((yyval.action), (yyvsp[(10) - (10)].action));			  /* ..here */
		  bufferWriteU8((yyval.action), SWFACTION_JUMP);
		  bufferWriteS16((yyval.action), 2);
		  bufferWriteS16((yyval.action), bufferLength((yyvsp[(8) - (10)].action)));
		  bufferConcat((yyval.action), (yyvsp[(8) - (10)].action)); }
    break;

  case 23:
#line 264 "swf4compiler.y"
    { (yyval.action) = (yyvsp[(5) - (8)].action);
		  bufferWriteU8((yyval.action), SWFACTION_WAITFORFRAME2);
		  bufferWriteS16((yyval.action), 1);
		  bufferWriteU8((yyval.action), 1);		/* if not loaded, jump to.. */
		  bufferWriteU8((yyval.action), SWFACTION_JUMP);
		  bufferWriteS16((yyval.action), 2);
		  bufferWriteS16((yyval.action), 5);
		  bufferWriteU8((yyval.action), SWFACTION_JUMP);	  /* ..here */
		  bufferWriteS16((yyval.action), 2);
		  bufferWriteS16((yyval.action), bufferLength((yyvsp[(8) - (8)].action)));	  /* ..and then out */
		  bufferConcat((yyval.action), (yyvsp[(8) - (8)].action)); }
    break;

  case 24:
#line 278 "swf4compiler.y"
    { (yyval.action) = (yyvsp[(6) - (9)].action);
		  bufferWriteU8((yyval.action), SWFACTION_WAITFORFRAME2);
		  bufferWriteS16((yyval.action), 1);
		  bufferWriteU8((yyval.action), 1);		/* if not loaded, jump to.. */
		  bufferWriteU8((yyval.action), SWFACTION_JUMP);
		  bufferWriteS16((yyval.action), 2);
		  bufferWriteS16((yyval.action), bufferLength((yyvsp[(9) - (9)].action)));
		  bufferConcat((yyval.action), (yyvsp[(9) - (9)].action)); }
    break;

  case 25:
#line 288 "swf4compiler.y"
    { bufferWriteU8((yyvsp[(3) - (7)].action), SWFACTION_IF);
		  bufferWriteS16((yyvsp[(3) - (7)].action), 2);
		  bufferWriteS16((yyvsp[(3) - (7)].action), bufferLength((yyvsp[(7) - (7)].action))+5);
		  bufferConcat((yyvsp[(3) - (7)].action), (yyvsp[(7) - (7)].action));
		  bufferWriteU8((yyvsp[(3) - (7)].action), SWFACTION_JUMP);
		  bufferWriteS16((yyvsp[(3) - (7)].action), 2);
		  bufferWriteS16((yyvsp[(3) - (7)].action), bufferLength((yyvsp[(5) - (7)].action)));
		  bufferConcat((yyvsp[(3) - (7)].action), (yyvsp[(5) - (7)].action));
		  (yyval.action) = (yyvsp[(3) - (7)].action); }
    break;

  case 26:
#line 299 "swf4compiler.y"
    { bufferWriteU8((yyvsp[(3) - (5)].action), SWFACTION_LOGICALNOT);
		  bufferWriteU8((yyvsp[(3) - (5)].action), SWFACTION_IF);
		  bufferWriteS16((yyvsp[(3) - (5)].action), 2);
		  bufferWriteS16((yyvsp[(3) - (5)].action), bufferLength((yyvsp[(5) - (5)].action)));
		  bufferConcat((yyvsp[(3) - (5)].action), (yyvsp[(5) - (5)].action));
		  (yyval.action) = (yyvsp[(3) - (5)].action); }
    break;

  case 27:
#line 308 "swf4compiler.y"
    { (yyval.action) = NULL; }
    break;

  case 28:
#line 309 "swf4compiler.y"
    { (yyval.action) = (yyvsp[(1) - (1)].action); }
    break;

  case 29:
#line 334 "swf4compiler.y"
    { (yyval.action) = newBuffer();
		  bufferWriteU8((yyval.action), SWFACTION_WAITFORFRAME);
		  bufferWriteS16((yyval.action), 3);
		  bufferWriteS16((yyval.action), atoi((yyvsp[(6) - (9)].str)));
		  free((yyvsp[(6) - (9)].str));
		  bufferWriteU8((yyval.action), 1);		/* if not loaded, jump to.. */
		  bufferWriteU8((yyval.action), SWFACTION_JUMP);
		  bufferWriteS16((yyval.action), 2);
		  bufferWriteS16((yyval.action), bufferLength((yyvsp[(9) - (9)].action))+5);
		  bufferConcat((yyval.action), (yyvsp[(9) - (9)].action));				  /* ..here */
		  bufferWriteU8((yyval.action), SWFACTION_JUMP);
		  bufferWriteS16((yyval.action), 2);
		  bufferWriteS16((yyval.action), -(bufferLength((yyval.action))+2)); }
    break;

  case 30:
#line 349 "swf4compiler.y"
    { (yyval.action) = (yyvsp[(3) - (5)].action);
		  bufferWriteU8((yyval.action), SWFACTION_LOGICALNOT);
		  bufferWriteU8((yyval.action), SWFACTION_IF);
		  bufferWriteS16((yyval.action), 2);
		  bufferWriteS16((yyval.action), bufferLength((yyvsp[(5) - (5)].action))+5);
		  bufferConcat((yyval.action), (yyvsp[(5) - (5)].action));
		  bufferWriteU8((yyval.action), SWFACTION_JUMP);
		  bufferWriteS16((yyval.action), 2);
		  bufferWriteS16((yyval.action), -(bufferLength((yyval.action))+2));
		  bufferResolveJumps((yyval.action)); }
    break;

  case 31:
#line 361 "swf4compiler.y"
    { (yyval.action) = (yyvsp[(2) - (6)].action);
		  bufferConcat((yyval.action), (yyvsp[(5) - (6)].action));
		  bufferWriteU8((yyval.action), SWFACTION_IF);
		  bufferWriteS16((yyval.action), 2);
		  bufferWriteS16((yyval.action), -(bufferLength((yyval.action))+2));
		  bufferResolveJumps((yyval.action)); }
    break;

  case 32:
#line 369 "swf4compiler.y"
    { if (!(yyvsp[(5) - (9)].action))
                    (yyvsp[(5) - (9)].action) = newBuffer();
                  else {
                    bufferWriteU8((yyvsp[(5) - (9)].action), SWFACTION_LOGICALNOT);
                    bufferWriteU8((yyvsp[(5) - (9)].action), SWFACTION_IF);
                    bufferWriteS16((yyvsp[(5) - (9)].action), 2);
                    bufferWriteS16((yyvsp[(5) - (9)].action), bufferLength((yyvsp[(9) - (9)].action))+bufferLength((yyvsp[(7) - (9)].action))+5);
                  }
                  bufferConcat((yyvsp[(5) - (9)].action), (yyvsp[(9) - (9)].action));
                  bufferConcat((yyvsp[(5) - (9)].action), (yyvsp[(7) - (9)].action));
                  bufferWriteU8((yyvsp[(5) - (9)].action), SWFACTION_JUMP);
                  bufferWriteS16((yyvsp[(5) - (9)].action), 2);
                  bufferWriteS16((yyvsp[(5) - (9)].action), -(bufferLength((yyvsp[(5) - (9)].action))+2));
                  bufferResolveJumps((yyvsp[(5) - (9)].action));
                  (yyval.action) = (yyvsp[(3) - (9)].action);
                  if(!(yyval.action)) (yyval.action) = newBuffer();
                  bufferConcat((yyval.action), (yyvsp[(5) - (9)].action));
                }
    break;

  case 33:
#line 390 "swf4compiler.y"
    { (yyval.action) = NULL; }
    break;

  case 35:
#line 396 "swf4compiler.y"
    { (yyval.action) = newBuffer();
		  bufferWriteU8((yyval.action), SWFACTION_JUMP);
		  bufferWriteS16((yyval.action), 2);
		  bufferWriteS16((yyval.action), MAGIC_CONTINUE_NUMBER); }
    break;

  case 36:
#line 404 "swf4compiler.y"
    { (yyval.action) = newBuffer();
		  bufferWriteU8((yyval.action), SWFACTION_JUMP);
		  bufferWriteS16((yyval.action), 2);
		  bufferWriteS16((yyval.action), MAGIC_BREAK_NUMBER); }
    break;

  case 37:
#line 412 "swf4compiler.y"
    { (yyval.getURLMethod) = GETURL_METHOD_NOSEND; }
    break;

  case 38:
#line 414 "swf4compiler.y"
    { if(strcmp((yyvsp[(2) - (2)].str), "GET") == 0)
				    (yyval.getURLMethod) = GETURL_METHOD_GET;
				  else if(strcmp((yyvsp[(2) - (2)].str), "POST") == 0)
				    (yyval.getURLMethod) = GETURL_METHOD_POST; }
    break;

  case 39:
#line 422 "swf4compiler.y"
    { (yyval.action) = newBuffer();
		  bufferWriteString((yyval.action), "_level", 7);
		  bufferConcat((yyval.action), (yyvsp[(1) - (1)].action));
		  bufferWriteOp((yyval.action), SWFACTION_STRINGCONCAT); }
    break;

  case 40:
#line 430 "swf4compiler.y"
    { (yyval.action) = newBuffer();
		  bufferWriteU8((yyval.action), SWFACTION_ENDDRAG); }
    break;

  case 41:
#line 434 "swf4compiler.y"
    { (yyval.action) = newBuffer();
		  bufferWriteString((yyval.action), (yyvsp[(3) - (4)].str), strlen((yyvsp[(3) - (4)].str))+1);
		  bufferWriteU8((yyval.action), SWFACTION_CALLFRAME);
		  bufferWriteS16((yyval.action), 0);
		  free((yyvsp[(3) - (4)].str)); }
    break;

  case 42:
#line 441 "swf4compiler.y"
    { (yyval.action) = newBuffer();
		  bufferWriteString((yyval.action), (yyvsp[(3) - (4)].str), strlen((yyvsp[(3) - (4)].str))+1);
		  bufferWriteU8((yyval.action), SWFACTION_CALLFRAME);
		  bufferWriteS16((yyval.action), 0);
		  free((yyvsp[(3) - (4)].str)); }
    break;

  case 43:
#line 448 "swf4compiler.y"
    { (yyval.action) = (yyvsp[(3) - (4)].action);
		  bufferWriteU8((yyval.action), SWFACTION_REMOVECLIP); }
    break;

  case 44:
#line 452 "swf4compiler.y"
    { (yyval.action) = (yyvsp[(3) - (4)].action);
		  bufferWriteU8((yyval.action), SWFACTION_TRACE); }
    break;

  case 45:
#line 457 "swf4compiler.y"
    { (yyval.action) = (yyvsp[(3) - (6)].action);
		  bufferConcat((yyval.action), (yyvsp[(5) - (6)].action));
		  bufferWriteU8((yyval.action), SWFACTION_GETURL2);
		  bufferWriteS16((yyval.action), 1);
		  bufferWriteU8((yyval.action), GETURL_METHOD_NOSEND); }
    break;

  case 46:
#line 464 "swf4compiler.y"
    { (yyval.action) = (yyvsp[(3) - (7)].action);
		  bufferConcat((yyval.action), (yyvsp[(5) - (7)].action));
		  bufferWriteU8((yyval.action), SWFACTION_GETURL2);
		  bufferWriteS16((yyval.action), 1);
		  bufferWriteU8((yyval.action), (yyvsp[(6) - (7)].getURLMethod)); }
    break;

  case 47:
#line 471 "swf4compiler.y"
    { (yyval.action) = newBuffer();
		  bufferWriteU8((yyval.action), SWFACTION_GETURL);
		  bufferWriteS16((yyval.action), strlen((yyvsp[(3) - (6)].str)) + strlen((yyvsp[(5) - (6)].str)) + 2);
		  bufferWriteHardString((yyval.action), (yyvsp[(3) - (6)].str), strlen((yyvsp[(3) - (6)].str)));
		  bufferWriteU8((yyval.action), 0);
		  bufferWriteHardString((yyval.action), (yyvsp[(5) - (6)].str), strlen((yyvsp[(5) - (6)].str)));
		  bufferWriteU8((yyval.action), 0); }
    break;

  case 48:
#line 480 "swf4compiler.y"
    { (yyval.action) = (yyvsp[(3) - (7)].action);
		  bufferConcat((yyval.action), (yyvsp[(5) - (7)].action));
		  bufferWriteU8((yyval.action), SWFACTION_GETURL2);
		  bufferWriteS16((yyval.action), 1);
		  bufferWriteU8((yyval.action), (yyvsp[(6) - (7)].getURLMethod) | GETURL_LOADMOVIE); }
    break;

  case 49:
#line 487 "swf4compiler.y"
    { (yyval.action) = (yyvsp[(3) - (7)].action);
		  bufferConcat((yyval.action), (yyvsp[(5) - (7)].action));
		  bufferWriteOp((yyval.action), SWFACTION_GETURL2);
		  bufferWriteS16((yyval.action), 1);
		  bufferWriteU8((yyval.action), (yyvsp[(6) - (7)].getURLMethod)); }
    break;

  case 50:
#line 494 "swf4compiler.y"
    { (yyval.action) = (yyvsp[(3) - (7)].action);
		  bufferConcat((yyval.action), (yyvsp[(5) - (7)].action));
		  bufferWriteU8((yyval.action), SWFACTION_GETURL2);
		  bufferWriteS16((yyval.action), 1);
		  bufferWriteU8((yyval.action), 0xc0 + (yyvsp[(6) - (7)].getURLMethod)); }
    break;

  case 51:
#line 502 "swf4compiler.y"
    { (yyval.action) = newBuffer();
		  bufferWriteString((yyval.action), "0", 2); /* no constraint */
		  bufferConcat((yyval.action), (yyvsp[(5) - (6)].action));
		  bufferConcat((yyval.action), (yyvsp[(3) - (6)].action));
		  bufferWriteU8((yyval.action), SWFACTION_STARTDRAG); }
    break;

  case 52:
#line 509 "swf4compiler.y"
    { (yyval.action) = newBuffer();
		  bufferConcat((yyval.action), (yyvsp[(7) - (14)].action));
		  bufferConcat((yyval.action), (yyvsp[(11) - (14)].action));
		  bufferConcat((yyval.action), (yyvsp[(9) - (14)].action));
		  bufferConcat((yyval.action), (yyvsp[(13) - (14)].action));
		  bufferWriteString((yyval.action), "1", 2); /* has constraint */
		  bufferConcat((yyval.action), (yyvsp[(5) - (14)].action));
		  bufferConcat((yyval.action), (yyvsp[(3) - (14)].action));
		  bufferWriteU8((yyval.action), SWFACTION_STARTDRAG); }
    break;

  case 53:
#line 521 "swf4compiler.y"
    { (yyval.action) = (yyvsp[(3) - (8)].action);
		  bufferConcat((yyval.action), (yyvsp[(5) - (8)].action));
		  bufferConcat((yyval.action), (yyvsp[(7) - (8)].action));
		  bufferWriteWTHITProperty((yyval.action));
		  bufferWriteU8((yyval.action), SWFACTION_ADD); /* see docs for explanation */
		  bufferWriteU8((yyval.action), SWFACTION_DUPLICATECLIP); }
    break;

  case 54:
#line 530 "swf4compiler.y"
    { (yyval.action) = newBuffer();
		  bufferWriteU8((yyval.action), SWFACTION_NEXTFRAME); }
    break;

  case 55:
#line 534 "swf4compiler.y"
    { (yyval.action) = newBuffer();
		  bufferWriteU8((yyval.action), SWFACTION_PREVFRAME); }
    break;

  case 56:
#line 538 "swf4compiler.y"
    { (yyval.action) = newBuffer();
		  bufferWriteU8((yyval.action), SWFACTION_PLAY); }
    break;

  case 57:
#line 542 "swf4compiler.y"
    { (yyval.action) = newBuffer();
		  bufferWriteU8((yyval.action), SWFACTION_STOP); }
    break;

  case 58:
#line 546 "swf4compiler.y"
    { (yyval.action) = newBuffer();
		  bufferWriteU8((yyval.action), SWFACTION_TOGGLEQUALITY); }
    break;

  case 59:
#line 550 "swf4compiler.y"
    { (yyval.action) = newBuffer();
		  bufferWriteU8((yyval.action), SWFACTION_STOPSOUNDS); }
    break;

  case 60:
#line 554 "swf4compiler.y"
    { (yyval.action) = newBuffer();
		  bufferWriteU8((yyval.action), SWFACTION_GOTOFRAME);
		  bufferWriteS16((yyval.action), 2);
		  bufferWriteS16((yyval.action), atoi((yyvsp[(3) - (4)].str)));
		  free((yyvsp[(3) - (4)].str)); }
    break;

  case 61:
#line 561 "swf4compiler.y"
    { (yyval.action) = newBuffer();
		  bufferWriteU8((yyval.action), SWFACTION_GOTOLABEL);
		  bufferWriteS16((yyval.action), strlen((yyvsp[(3) - (4)].str))+1);
		  bufferWriteHardString((yyval.action), (yyvsp[(3) - (4)].str), strlen((yyvsp[(3) - (4)].str))+1);
		  free((yyvsp[(3) - (4)].str)); }
    break;

  case 62:
#line 568 "swf4compiler.y"
    { (yyval.action) = newBuffer();
		  bufferWriteU8((yyval.action), SWFACTION_GOTOFRAME);
		  bufferWriteS16((yyval.action), 2);
		  bufferWriteS16((yyval.action), atoi((yyvsp[(3) - (4)].str)));
		  bufferWriteU8((yyval.action), SWFACTION_PLAY);
		  free((yyvsp[(3) - (4)].str)); }
    break;

  case 63:
#line 576 "swf4compiler.y"
    { (yyval.action) = newBuffer();
		  bufferWriteU8((yyval.action), SWFACTION_GOTOLABEL);
		  bufferWriteS16((yyval.action), strlen((yyvsp[(3) - (4)].str))+1);
		  bufferWriteHardString((yyval.action), (yyvsp[(3) - (4)].str), strlen((yyvsp[(3) - (4)].str))+1);
		  bufferWriteU8((yyval.action), SWFACTION_PLAY);
		  free((yyvsp[(3) - (4)].str)); }
    break;

  case 64:
#line 584 "swf4compiler.y"
    { (yyval.action) = newBuffer();
		  bufferWriteU8((yyval.action), SWFACTION_GOTOFRAME);
		  bufferWriteS16((yyval.action), 2);
		  bufferWriteS16((yyval.action), atoi((yyvsp[(3) - (4)].str)));
		  bufferWriteU8((yyval.action), SWFACTION_STOP);
		  free((yyvsp[(3) - (4)].str)); }
    break;

  case 65:
#line 592 "swf4compiler.y"
    { (yyval.action) = newBuffer();
		  bufferWriteU8((yyval.action), SWFACTION_GOTOLABEL);
		  bufferWriteS16((yyval.action), strlen((yyvsp[(3) - (4)].str))+1);
		  bufferWriteHardString((yyval.action), (yyvsp[(3) - (4)].str), strlen((yyvsp[(3) - (4)].str))+1);
		  bufferWriteU8((yyval.action), SWFACTION_STOP);
		  free((yyvsp[(3) - (4)].str)); }
    break;

  case 66:
#line 600 "swf4compiler.y"
    { (yyval.action) = newBuffer();
		  bufferWriteU8((yyval.action), SWFACTION_SETTARGET);
		  bufferWriteS16((yyval.action), strlen((yyvsp[(3) - (4)].str))+1);
		  bufferWriteHardString((yyval.action), (yyvsp[(3) - (4)].str), strlen((yyvsp[(3) - (4)].str))+1);
		  free((yyvsp[(3) - (4)].str)); }
    break;

  case 67:
#line 607 "swf4compiler.y"
    { (yyval.action) = (yyvsp[(3) - (4)].action);
		  bufferWriteU8((yyval.action), SWFACTION_SETTARGET2); }
    break;

  case 68:
#line 611 "swf4compiler.y"
    { (yyval.action) = newBuffer();
			/* SetTarget(STRING) */
		  bufferWriteU8((yyval.action), SWFACTION_SETTARGET);
		  bufferWriteS16((yyval.action), strlen((yyvsp[(3) - (5)].str))+1);
		  bufferWriteHardString((yyval.action), (yyvsp[(3) - (5)].str), strlen((yyvsp[(3) - (5)].str))+1);
			/* stmt */
		  bufferConcat((yyval.action), (yyvsp[(5) - (5)].action));
			/* SetTarget('') */
		  bufferWriteU8((yyval.action), SWFACTION_SETTARGET);
		  bufferWriteS16((yyval.action), 1);
		  bufferWriteU8((yyval.action), 0);
		  free((yyvsp[(3) - (5)].str)); }
    break;

  case 69:
#line 625 "swf4compiler.y"
    { (yyval.action) = (yyvsp[(3) - (5)].action);
			/* SetTarget(expr) */
		  bufferWriteU8((yyval.action), SWFACTION_SETTARGET2); 
			/* stmt */
		  bufferConcat((yyval.action), (yyvsp[(5) - (5)].action));
			/* SetTarget('') */
		  bufferWriteU8((yyval.action), SWFACTION_SETTARGET);
		  bufferWriteS16((yyval.action), 1);
		  bufferWriteU8((yyval.action), 0); }
    break;

  case 70:
#line 638 "swf4compiler.y"
    { (yyval.action) = (yyvsp[(3) - (4)].action);
		  bufferWriteU8((yyval.action), SWFACTION_GETVARIABLE); }
    break;

  case 71:
#line 642 "swf4compiler.y"
    { (yyval.action) = newBuffer();
		  bufferWriteU8((yyval.action), SWFACTION_GETTIME); }
    break;

  case 72:
#line 646 "swf4compiler.y"
    { (yyval.action) = (yyvsp[(3) - (4)].action);
		  bufferWriteU8((yyval.action), SWFACTION_RANDOMNUMBER); }
    break;

  case 73:
#line 650 "swf4compiler.y"
    { (yyval.action) = (yyvsp[(3) - (4)].action);
		  bufferWriteU8((yyval.action), SWFACTION_STRINGLENGTH); }
    break;

  case 74:
#line 654 "swf4compiler.y"
    { (yyval.action) = (yyvsp[(3) - (4)].action);
		  bufferWriteU8((yyval.action), SWFACTION_INT); }
    break;

  case 75:
#line 658 "swf4compiler.y"
    { (yyval.action) = (yyvsp[(3) - (4)].action);
		  bufferWriteU8((yyval.action), SWFACTION_ORD); }
    break;

  case 76:
#line 662 "swf4compiler.y"
    { (yyval.action) = (yyvsp[(3) - (4)].action);
		  bufferWriteU8((yyval.action), SWFACTION_CHR); }
    break;

  case 77:
#line 666 "swf4compiler.y"
    { (yyval.action) = (yyvsp[(3) - (6)].action);
		  bufferConcat((yyval.action), (yyvsp[(5) - (6)].action));
		  bufferWriteU8((yyval.action), SWFACTION_STRINGCONCAT); }
    break;

  case 78:
#line 671 "swf4compiler.y"
    { (yyval.action) = (yyvsp[(3) - (8)].action);
		  bufferConcat((yyval.action), (yyvsp[(5) - (8)].action));
		  bufferConcat((yyval.action), (yyvsp[(7) - (8)].action));
		  bufferWriteU8((yyval.action), SWFACTION_SUBSTRING); }
    break;

  case 79:
#line 677 "swf4compiler.y"
    { (yyval.action) = newBuffer();
		  bufferConcat((yyval.action), (yyvsp[(3) - (6)].action));
		  bufferWriteProperty((yyval.action), (yyvsp[(5) - (6)].str));
		  bufferWriteU8((yyval.action), SWFACTION_GETPROPERTY);
		  free((yyvsp[(5) - (6)].str)); }
    break;

  case 80:
#line 686 "swf4compiler.y"
    { (yyval.action) = newBuffer();
		  bufferWriteBuffer((yyval.action), (yyvsp[(1) - (2)].action));
		  bufferWriteU8((yyval.action), SWFACTION_GETVARIABLE);
		  bufferWriteBuffer((yyval.action), (yyvsp[(1) - (2)].action));
		  bufferConcat((yyval.action), (yyvsp[(1) - (2)].action));
		  bufferWriteU8((yyval.action), SWFACTION_GETVARIABLE);
		  bufferWriteString((yyval.action), "1", 2);
		  bufferWriteU8((yyval.action), SWFACTION_ADD);
		  bufferWriteU8((yyval.action), SWFACTION_SETVARIABLE); }
    break;

  case 81:
#line 697 "swf4compiler.y"
    { (yyval.action) = newBuffer();
		  bufferWriteBuffer((yyval.action), (yyvsp[(1) - (2)].action));
		  bufferWriteU8((yyval.action), SWFACTION_GETVARIABLE);
		  bufferWriteBuffer((yyval.action), (yyvsp[(1) - (2)].action));
		  bufferConcat((yyval.action), (yyvsp[(1) - (2)].action));
		  bufferWriteU8((yyval.action), SWFACTION_GETVARIABLE);
		  bufferWriteString((yyval.action), "1", 2);
		  bufferWriteU8((yyval.action), SWFACTION_SUBTRACT);
		  bufferWriteU8((yyval.action), SWFACTION_SETVARIABLE); }
    break;

  case 83:
#line 713 "swf4compiler.y"
    { (yyval.action) = (yyvsp[(2) - (3)].action); }
    break;

  case 84:
#line 716 "swf4compiler.y"
    { (yyval.action) = newBuffer();
		  bufferWriteString((yyval.action), (yyvsp[(1) - (1)].str), strlen((yyvsp[(1) - (1)].str))+1);
		  free((yyvsp[(1) - (1)].str)); }
    break;

  case 85:
#line 721 "swf4compiler.y"
    { (yyval.action) = newBuffer();
		  bufferWriteString((yyval.action), "-", 2);
		  bufferWriteString((yyval.action), (yyvsp[(2) - (2)].str), strlen((yyvsp[(2) - (2)].str))+1);
		  free((yyvsp[(2) - (2)].str)); }
    break;

  case 86:
#line 727 "swf4compiler.y"
    { (yyval.action) = newBuffer();
		  bufferWriteString((yyval.action), (yyvsp[(1) - (1)].str), strlen((yyvsp[(1) - (1)].str))+1);
		  free((yyvsp[(1) - (1)].str)); }
    break;

  case 87:
#line 732 "swf4compiler.y"
    { (yyval.action) = newBuffer();
		  bufferWriteString((yyval.action), (yyvsp[(1) - (1)].str), strlen((yyvsp[(1) - (1)].str))+1);
		  bufferWriteU8((yyval.action), SWFACTION_GETVARIABLE);
		  free((yyvsp[(1) - (1)].str)); }
    break;

  case 88:
#line 738 "swf4compiler.y"
    { (yyval.action) = newBuffer();
		  bufferWriteString((yyval.action), (yyvsp[(1) - (1)].str), strlen((yyvsp[(1) - (1)].str))+1);
		  free((yyvsp[(1) - (1)].str)); }
    break;

  case 89:
#line 743 "swf4compiler.y"
    { (yyval.action) = newBuffer();
		  bufferWriteString((yyval.action), (yyvsp[(1) - (3)].str), strlen((yyvsp[(1) - (3)].str))+1);
		  bufferWriteProperty((yyval.action), (yyvsp[(3) - (3)].str));
		  bufferWriteU8((yyval.action), SWFACTION_GETPROPERTY);
		  free((yyvsp[(3) - (3)].str));
		  free((yyvsp[(1) - (3)].str)); }
    break;

  case 90:
#line 751 "swf4compiler.y"
    { (yyval.action) = newBuffer();
		  bufferWriteString((yyval.action), (yyvsp[(2) - (4)].str), strlen((yyvsp[(2) - (4)].str))+1);
		  bufferWriteProperty((yyval.action), (yyvsp[(4) - (4)].str));
		  bufferWriteString((yyval.action), (yyvsp[(2) - (4)].str), strlen((yyvsp[(2) - (4)].str))+1);
		  bufferWriteProperty((yyval.action), (yyvsp[(4) - (4)].str));
		  bufferWriteString((yyval.action), (yyvsp[(2) - (4)].str), strlen((yyvsp[(2) - (4)].str))+1);
		  bufferWriteProperty((yyval.action), (yyvsp[(4) - (4)].str));
		  bufferWriteString((yyval.action), "1", 2);
		  bufferWriteU8((yyval.action), SWFACTION_ADD);
		  bufferWriteU8((yyval.action), SWFACTION_SETPROPERTY);
		  bufferWriteU8((yyval.action), SWFACTION_GETPROPERTY);
		  free((yyvsp[(2) - (4)].str));
		  free((yyvsp[(4) - (4)].str)); }
    break;

  case 91:
#line 766 "swf4compiler.y"
    { (yyval.action) = (yyvsp[(2) - (2)].action);
		  bufferWriteU8((yyval.action), SWFACTION_PUSHDUP);
		  bufferWriteU8((yyval.action), SWFACTION_PUSHDUP);
		  bufferWriteU8((yyval.action), SWFACTION_GETVARIABLE);
		  bufferWriteString((yyval.action), "1", 2);
		  bufferWriteU8((yyval.action), SWFACTION_ADD);
		  bufferWriteU8((yyval.action), SWFACTION_SETVARIABLE);
		  bufferWriteU8((yyval.action), SWFACTION_GETVARIABLE); }
    break;

  case 92:
#line 776 "swf4compiler.y"
    { (yyval.action) = newBuffer();
		  bufferWriteString((yyval.action), (yyvsp[(2) - (4)].str), strlen((yyvsp[(2) - (4)].str))+1);
		  bufferWriteProperty((yyval.action), (yyvsp[(4) - (4)].str));
		  bufferWriteString((yyval.action), (yyvsp[(2) - (4)].str), strlen((yyvsp[(2) - (4)].str))+1);
		  bufferWriteProperty((yyval.action), (yyvsp[(4) - (4)].str));
		  bufferWriteString((yyval.action), (yyvsp[(2) - (4)].str), strlen((yyvsp[(2) - (4)].str))+1);
		  bufferWriteProperty((yyval.action), (yyvsp[(4) - (4)].str));
		  bufferWriteString((yyval.action), "1", 2);
		  bufferWriteU8((yyval.action), SWFACTION_ADD);
		  bufferWriteU8((yyval.action), SWFACTION_SETPROPERTY);
		  bufferWriteU8((yyval.action), SWFACTION_GETPROPERTY);
		  free((yyvsp[(2) - (4)].str));
		  free((yyvsp[(4) - (4)].str)); }
    break;

  case 93:
#line 791 "swf4compiler.y"
    { (yyval.action) = (yyvsp[(2) - (2)].action);
		  bufferWriteU8((yyval.action), SWFACTION_PUSHDUP);
		  bufferWriteU8((yyval.action), SWFACTION_PUSHDUP);
		  bufferWriteU8((yyval.action), SWFACTION_GETVARIABLE);
		  bufferWriteString((yyval.action), "1", 2);
		  bufferWriteU8((yyval.action), SWFACTION_SUBTRACT);
		  bufferWriteU8((yyval.action), SWFACTION_SETVARIABLE);
		  bufferWriteU8((yyval.action), SWFACTION_GETVARIABLE); }
    break;

  case 94:
#line 801 "swf4compiler.y"
    { (yyval.action) = (yyvsp[(2) - (2)].action);
		  bufferWriteString((yyvsp[(2) - (2)].action), "-1", 3);
		  bufferWriteU8((yyvsp[(2) - (2)].action), SWFACTION_MULTIPLY); }
    break;

  case 95:
#line 806 "swf4compiler.y"
    { (yyval.action) = (yyvsp[(2) - (2)].action);
		  bufferWriteU8((yyvsp[(2) - (2)].action), SWFACTION_LOGICALNOT); }
    break;

  case 96:
#line 810 "swf4compiler.y"
    { (yyval.action) = (yyvsp[(1) - (3)].action);
		  bufferConcat((yyval.action), (yyvsp[(3) - (3)].action));
		  bufferWriteU8((yyval.action), SWFACTION_PUSHDUP);
		  bufferWriteU8((yyval.action), SWFACTION_SETVARIABLE); }
    break;

  case 97:
#line 816 "swf4compiler.y"
    { (yyval.action) = (yyvsp[(1) - (3)].action);
		  bufferConcat((yyval.action), (yyvsp[(3) - (3)].action));
		  bufferWriteU8((yyval.action), SWFACTION_MULTIPLY); }
    break;

  case 98:
#line 821 "swf4compiler.y"
    { (yyval.action) = (yyvsp[(1) - (3)].action);
		  bufferConcat((yyval.action), (yyvsp[(3) - (3)].action));
		  bufferWriteU8((yyval.action), SWFACTION_DIVIDE); }
    break;

  case 99:
#line 826 "swf4compiler.y"
    { (yyval.action) = (yyvsp[(1) - (3)].action);
		  bufferConcat((yyval.action), (yyvsp[(3) - (3)].action));
		  bufferWriteU8((yyval.action), SWFACTION_ADD); }
    break;

  case 100:
#line 831 "swf4compiler.y"
    { (yyval.action) = (yyvsp[(1) - (3)].action);
		  bufferConcat((yyval.action), (yyvsp[(3) - (3)].action));
		  bufferWriteU8((yyval.action), SWFACTION_SUBTRACT); }
    break;

  case 101:
#line 836 "swf4compiler.y"
    { (yyval.action) = (yyvsp[(1) - (3)].action);
		  bufferConcat((yyval.action), (yyvsp[(3) - (3)].action));
		  bufferWriteU8((yyval.action), SWFACTION_STRINGCONCAT); }
    break;

  case 102:
#line 841 "swf4compiler.y"
    { (yyval.action) = (yyvsp[(1) - (3)].action);
		  bufferConcat((yyval.action), (yyvsp[(3) - (3)].action));
		  bufferWriteU8((yyval.action), SWFACTION_LESSTHAN); }
    break;

  case 103:
#line 846 "swf4compiler.y"
    { (yyval.action) = (yyvsp[(3) - (3)].action);
		  bufferConcat((yyval.action), (yyvsp[(1) - (3)].action));
		  bufferWriteU8((yyval.action), SWFACTION_LESSTHAN); }
    break;

  case 104:
#line 851 "swf4compiler.y"
    { (yyval.action) = (yyvsp[(3) - (3)].action);
		  bufferConcat((yyval.action), (yyvsp[(1) - (3)].action));
		  bufferWriteU8((yyval.action), SWFACTION_LESSTHAN);
		  bufferWriteU8((yyval.action), SWFACTION_LOGICALNOT); }
    break;

  case 105:
#line 857 "swf4compiler.y"
    { bufferConcat((yyvsp[(1) - (3)].action), (yyvsp[(3) - (3)].action));
		  bufferWriteU8((yyvsp[(1) - (3)].action), SWFACTION_LESSTHAN);
		  bufferWriteU8((yyvsp[(1) - (3)].action), SWFACTION_LOGICALNOT); }
    break;

  case 106:
#line 862 "swf4compiler.y"
    { bufferConcat((yyvsp[(1) - (3)].action), (yyvsp[(3) - (3)].action));
		  bufferWriteU8((yyvsp[(1) - (3)].action), SWFACTION_STRINGEQ);
		  bufferWriteU8((yyvsp[(1) - (3)].action), SWFACTION_LOGICALNOT); }
    break;

  case 107:
#line 867 "swf4compiler.y"
    { bufferConcat((yyvsp[(1) - (3)].action), (yyvsp[(3) - (3)].action));
		  bufferWriteU8((yyvsp[(1) - (3)].action), SWFACTION_STRINGEQ); }
    break;

  case 108:
#line 871 "swf4compiler.y"
    { bufferConcat((yyvsp[(1) - (3)].action), (yyvsp[(3) - (3)].action));
		  bufferWriteU8((yyvsp[(1) - (3)].action), SWFACTION_STRINGCOMPARE); }
    break;

  case 109:
#line 875 "swf4compiler.y"
    { bufferConcat((yyvsp[(1) - (3)].action), (yyvsp[(3) - (3)].action));
		  bufferWriteU8((yyvsp[(1) - (3)].action), SWFACTION_EQUAL); }
    break;

  case 110:
#line 879 "swf4compiler.y"
    { bufferConcat((yyvsp[(1) - (3)].action), (yyvsp[(3) - (3)].action));
		  bufferWriteU8((yyvsp[(1) - (3)].action), SWFACTION_EQUAL);
		  bufferWriteU8((yyvsp[(1) - (3)].action), SWFACTION_LOGICALNOT); }
    break;

  case 111:
#line 884 "swf4compiler.y"
    { bufferConcat((yyvsp[(1) - (3)].action), (yyvsp[(3) - (3)].action));
		  bufferWriteU8((yyvsp[(1) - (3)].action), SWFACTION_LOGICALAND); }
    break;

  case 112:
#line 888 "swf4compiler.y"
    { bufferConcat((yyvsp[(1) - (3)].action), (yyvsp[(3) - (3)].action));
		  bufferWriteU8((yyvsp[(1) - (3)].action), SWFACTION_LOGICALOR); }
    break;

  case 113:
#line 892 "swf4compiler.y"
    { bufferWriteU8((yyvsp[(1) - (5)].action), SWFACTION_IF);
		  bufferWriteS16((yyvsp[(1) - (5)].action), 2);
		  bufferWriteS16((yyvsp[(1) - (5)].action), bufferLength((yyvsp[(5) - (5)].action))+5);
		  bufferConcat((yyvsp[(1) - (5)].action), (yyvsp[(5) - (5)].action));
		  bufferWriteU8((yyvsp[(1) - (5)].action), SWFACTION_JUMP);
		  bufferWriteS16((yyvsp[(1) - (5)].action), 2);
		  bufferWriteS16((yyvsp[(1) - (5)].action), bufferLength((yyvsp[(3) - (5)].action)));
		  bufferConcat((yyvsp[(1) - (5)].action), (yyvsp[(3) - (5)].action)); }
    break;

  case 115:
#line 906 "swf4compiler.y"
    { (yyval.str) = (yyvsp[(1) - (3)].str);
		  (yyval.str) = stringConcat((yyval.str), strdup(":"));
		  (yyval.str) = stringConcat((yyval.str), (yyvsp[(3) - (3)].str)); }
    break;

  case 116:
#line 913 "swf4compiler.y"
    { (yyval.str) = strdup(""); }
    break;

  case 117:
#line 916 "swf4compiler.y"
    { (yyval.str) = strdup(""); }
    break;

  case 118:
#line 919 "swf4compiler.y"
    { (yyval.str) = strdup("/"); }
    break;

  case 119:
#line 922 "swf4compiler.y"
    { (yyval.str) = strdup(".."); }
    break;

  case 120:
#line 925 "swf4compiler.y"
    { (yyval.str) = (yyvsp[(1) - (1)].str); }
    break;

  case 121:
#line 928 "swf4compiler.y"
    { (yyval.str) = (yyvsp[(1) - (1)].str); }
    break;

  case 122:
#line 933 "swf4compiler.y"
    { (yyval.action) = newBuffer();
		  bufferWriteString((yyval.action), (yyvsp[(1) - (1)].str), strlen((yyvsp[(1) - (1)].str))+1);
		  free((yyvsp[(1) - (1)].str)); }
    break;

  case 123:
#line 938 "swf4compiler.y"
    { (yyval.action) = newBuffer();
		  bufferWriteString((yyval.action), (yyvsp[(1) - (1)].str), strlen((yyvsp[(1) - (1)].str))+1);
		  free((yyvsp[(1) - (1)].str)); }
    break;

  case 124:
#line 942 "swf4compiler.y"
    { (yyval.action) = (yyvsp[(2) - (3)].action); }
    break;

  case 126:
#line 949 "swf4compiler.y"
    { asmBuffer = newBuffer(); }
    break;

  case 127:
#line 951 "swf4compiler.y"
    { (yyval.action) = asmBuffer; }
    break;

  case 129:
#line 956 "swf4compiler.y"
    { (yyval.action) = (yyvsp[(2) - (2)].action);
		  bufferWriteBuffer((yyval.action), (yyvsp[(2) - (2)].action));
		  bufferWriteU8((yyval.action), SWFACTION_GETVARIABLE);
		  bufferWriteString((yyval.action), "1", 2);
		  bufferWriteU8((yyval.action), SWFACTION_ADD);
		  bufferWriteU8((yyval.action), SWFACTION_SETVARIABLE); }
    break;

  case 130:
#line 964 "swf4compiler.y"
    { (yyval.action) = (yyvsp[(2) - (2)].action);
		  bufferWriteBuffer((yyval.action), (yyvsp[(2) - (2)].action));
		  bufferWriteU8((yyval.action), SWFACTION_GETVARIABLE);
		  bufferWriteString((yyval.action), "1", 2);
		  bufferWriteU8((yyval.action), SWFACTION_SUBTRACT);
		  bufferWriteU8((yyval.action), SWFACTION_SETVARIABLE); }
    break;

  case 131:
#line 972 "swf4compiler.y"
    { (yyval.action) = newBuffer();
		  bufferWriteString((yyval.action), (yyvsp[(2) - (4)].str), strlen((yyvsp[(2) - (4)].str))+1);
		  bufferWriteProperty((yyval.action), (yyvsp[(4) - (4)].str));
		  bufferWriteU8((yyval.action), SWFACTION_GETPROPERTY);
		  bufferWriteString((yyval.action), "1", 2);
		  bufferWriteU8((yyval.action), SWFACTION_ADD);
		  bufferWriteString((yyval.action), (yyvsp[(2) - (4)].str), strlen((yyvsp[(2) - (4)].str))+1);
		  bufferWriteProperty((yyval.action), (yyvsp[(4) - (4)].str));
		  bufferWriteU8((yyval.action), SWFACTION_SETPROPERTY);
		  free((yyvsp[(2) - (4)].str));
		  free((yyvsp[(4) - (4)].str)); }
    break;

  case 132:
#line 985 "swf4compiler.y"
    { (yyval.action) = newBuffer();
		  bufferWriteString((yyval.action), (yyvsp[(2) - (4)].str), strlen((yyvsp[(2) - (4)].str))+1);
		  bufferWriteProperty((yyval.action), (yyvsp[(4) - (4)].str));
		  bufferWriteU8((yyval.action), SWFACTION_GETPROPERTY);
		  bufferWriteString((yyval.action), "1", 2);
		  bufferWriteU8((yyval.action), SWFACTION_SUBTRACT);
		  bufferWriteString((yyval.action), (yyvsp[(2) - (4)].str), strlen((yyvsp[(2) - (4)].str))+1);
		  bufferWriteProperty((yyval.action), (yyvsp[(4) - (4)].str));
		  bufferWriteU8((yyval.action), SWFACTION_SETPROPERTY);
		  free((yyvsp[(2) - (4)].str));
		  free((yyvsp[(4) - (4)].str)); }
    break;

  case 133:
#line 998 "swf4compiler.y"
    { bufferConcat((yyvsp[(1) - (3)].action), (yyvsp[(3) - (3)].action));
		  bufferWriteU8((yyvsp[(1) - (3)].action), SWFACTION_SETVARIABLE); }
    break;

  case 134:
#line 1002 "swf4compiler.y"
    { bufferWriteBuffer((yyvsp[(1) - (3)].action), (yyvsp[(1) - (3)].action));
		  bufferWriteU8((yyvsp[(1) - (3)].action), SWFACTION_GETVARIABLE);
		  bufferConcat((yyvsp[(1) - (3)].action), (yyvsp[(3) - (3)].action));
		  bufferWriteU8((yyvsp[(1) - (3)].action), SWFACTION_MULTIPLY);
		  bufferWriteU8((yyvsp[(1) - (3)].action), SWFACTION_SETVARIABLE); }
    break;

  case 135:
#line 1009 "swf4compiler.y"
    { bufferWriteBuffer((yyvsp[(1) - (3)].action), (yyvsp[(1) - (3)].action));
		  bufferWriteU8((yyvsp[(1) - (3)].action), SWFACTION_GETVARIABLE);
		  bufferConcat((yyvsp[(1) - (3)].action), (yyvsp[(3) - (3)].action));
		  bufferWriteU8((yyvsp[(1) - (3)].action), SWFACTION_DIVIDE);
		  bufferWriteU8((yyvsp[(1) - (3)].action), SWFACTION_SETVARIABLE); }
    break;

  case 136:
#line 1016 "swf4compiler.y"
    { bufferWriteBuffer((yyvsp[(1) - (3)].action), (yyvsp[(1) - (3)].action));
		  bufferWriteU8((yyvsp[(1) - (3)].action), SWFACTION_GETVARIABLE);
		  bufferConcat((yyvsp[(1) - (3)].action), (yyvsp[(3) - (3)].action));
		  bufferWriteU8((yyvsp[(1) - (3)].action), SWFACTION_ADD);
		  bufferWriteU8((yyvsp[(1) - (3)].action), SWFACTION_SETVARIABLE); }
    break;

  case 137:
#line 1023 "swf4compiler.y"
    { bufferWriteBuffer((yyvsp[(1) - (3)].action), (yyvsp[(1) - (3)].action));
		  bufferWriteU8((yyvsp[(1) - (3)].action), SWFACTION_GETVARIABLE);
		  bufferConcat((yyvsp[(1) - (3)].action), (yyvsp[(3) - (3)].action));
		  bufferWriteU8((yyvsp[(1) - (3)].action), SWFACTION_SUBTRACT);
		  bufferWriteU8((yyvsp[(1) - (3)].action), SWFACTION_SETVARIABLE); }
    break;

  case 138:
#line 1030 "swf4compiler.y"
    { (yyval.action) = newBuffer();
		  bufferWriteString((yyval.action), (yyvsp[(1) - (5)].str), strlen((yyvsp[(1) - (5)].str))+1);
		  bufferWriteProperty((yyval.action), (yyvsp[(3) - (5)].str));
		  bufferConcat((yyval.action),(yyvsp[(5) - (5)].action));
		  bufferWriteU8((yyval.action), SWFACTION_SETPROPERTY);
		  free((yyvsp[(1) - (5)].str));
		  free((yyvsp[(3) - (5)].str)); }
    break;

  case 139:
#line 1039 "swf4compiler.y"
    { (yyval.action) = newBuffer();
		  bufferWriteString((yyval.action), (yyvsp[(1) - (5)].str), strlen((yyvsp[(1) - (5)].str))+1);
		  bufferWriteProperty((yyval.action), (yyvsp[(3) - (5)].str));
		  bufferWriteString((yyval.action), (yyvsp[(1) - (5)].str), strlen((yyvsp[(1) - (5)].str))+1);
		  bufferWriteProperty((yyval.action), (yyvsp[(3) - (5)].str));
		  bufferWriteU8((yyval.action), SWFACTION_GETPROPERTY);
		  bufferConcat((yyval.action), (yyvsp[(5) - (5)].action));
		  bufferWriteU8((yyval.action), SWFACTION_MULTIPLY);
		  bufferWriteU8((yyval.action), SWFACTION_SETPROPERTY);
		  free((yyvsp[(1) - (5)].str));
		  free((yyvsp[(3) - (5)].str)); }
    break;

  case 140:
#line 1052 "swf4compiler.y"
    { (yyval.action) = newBuffer();
		  bufferWriteString((yyval.action), (yyvsp[(1) - (5)].str), strlen((yyvsp[(1) - (5)].str))+1);
		  bufferWriteProperty((yyval.action), (yyvsp[(3) - (5)].str));
		  bufferWriteString((yyval.action), (yyvsp[(1) - (5)].str), strlen((yyvsp[(1) - (5)].str))+1);
		  bufferWriteProperty((yyval.action), (yyvsp[(3) - (5)].str));
		  bufferWriteU8((yyval.action), SWFACTION_GETPROPERTY);
		  bufferConcat((yyval.action), (yyvsp[(5) - (5)].action));
		  bufferWriteU8((yyval.action), SWFACTION_DIVIDE);
		  bufferWriteU8((yyval.action), SWFACTION_SETPROPERTY);
		  free((yyvsp[(1) - (5)].str));
		  free((yyvsp[(3) - (5)].str)); }
    break;

  case 141:
#line 1065 "swf4compiler.y"
    { (yyval.action) = newBuffer();
		  bufferWriteString((yyval.action), (yyvsp[(1) - (5)].str), strlen((yyvsp[(1) - (5)].str))+1);
		  bufferWriteProperty((yyval.action), (yyvsp[(3) - (5)].str));
		  bufferWriteString((yyval.action), (yyvsp[(1) - (5)].str), strlen((yyvsp[(1) - (5)].str))+1);
		  bufferWriteProperty((yyval.action), (yyvsp[(3) - (5)].str));
		  bufferWriteU8((yyval.action), SWFACTION_GETPROPERTY);
		  bufferConcat((yyval.action), (yyvsp[(5) - (5)].action));
		  bufferWriteU8((yyval.action), SWFACTION_ADD);
		  bufferWriteU8((yyval.action), SWFACTION_SETPROPERTY);
		  free((yyvsp[(1) - (5)].str));
		  free((yyvsp[(3) - (5)].str)); }
    break;

  case 142:
#line 1078 "swf4compiler.y"
    { (yyval.action) = newBuffer();
		  bufferWriteString((yyval.action), (yyvsp[(1) - (5)].str), strlen((yyvsp[(1) - (5)].str))+1);
		  bufferWriteProperty((yyval.action), (yyvsp[(3) - (5)].str));
		  bufferWriteString((yyval.action), (yyvsp[(1) - (5)].str), strlen((yyvsp[(1) - (5)].str))+1);
		  bufferWriteProperty((yyval.action), (yyvsp[(3) - (5)].str));
		  bufferWriteU8((yyval.action), SWFACTION_GETPROPERTY);
		  bufferConcat((yyval.action), (yyvsp[(5) - (5)].action));
		  bufferWriteU8((yyval.action), SWFACTION_SUBTRACT);
		  bufferWriteU8((yyval.action), SWFACTION_SETPROPERTY);
		  free((yyvsp[(1) - (5)].str));
		  free((yyvsp[(3) - (5)].str)); }
    break;

  case 144:
#line 1096 "swf4compiler.y"
    { (yyval.len) = bufferWriteU8(asmBuffer, PUSH_STRING);
				  (yyval.len) += bufferWriteHardString(asmBuffer, (yyvsp[(1) - (1)].str), strlen((yyvsp[(1) - (1)].str)) + 1); }
    break;

  case 145:
#line 1100 "swf4compiler.y"
    { (yyval.len) = (yyvsp[(1) - (1)].len); }
    break;

  case 146:
#line 1101 "swf4compiler.y"
    { (yyval.len) = (yyvsp[(1) - (3)].len) + (yyvsp[(3) - (3)].len); }
    break;

  case 148:
#line 1106 "swf4compiler.y"
    { (yyval.len) = (yyvsp[(1) - (2)].len) + (yyvsp[(2) - (2)].len); }
    break;

  case 149:
#line 1110 "swf4compiler.y"
    { (yyval.len) = bufferWritePushOp(asmBuffer);
				  (yyval.len) += bufferWriteS16(asmBuffer, 0); }
    break;

  case 150:
#line 1112 "swf4compiler.y"
    { (yyval.len) = (yyvsp[(2) - (3)].len) + (yyvsp[(3) - (3)].len);
			
				  bufferPatchLength(asmBuffer, (yyvsp[(3) - (3)].len)); }
    break;

  case 151:
#line 1116 "swf4compiler.y"
    { (yyval.len) = bufferWriteOp(asmBuffer, SWFACTION_ADD); }
    break;

  case 152:
#line 1117 "swf4compiler.y"
    { (yyval.len) = bufferWriteOp(asmBuffer, SWFACTION_SUBTRACT); }
    break;

  case 153:
#line 1118 "swf4compiler.y"
    { (yyval.len) = bufferWriteOp(asmBuffer, SWFACTION_MULTIPLY); }
    break;

  case 154:
#line 1119 "swf4compiler.y"
    { (yyval.len) = bufferWriteOp(asmBuffer, SWFACTION_DIVIDE); }
    break;

  case 155:
#line 1120 "swf4compiler.y"
    { (yyval.len) = bufferWriteOp(asmBuffer, SWFACTION_EQUAL); }
    break;

  case 156:
#line 1121 "swf4compiler.y"
    { (yyval.len) = bufferWriteOp(asmBuffer, SWFACTION_LESSTHAN); }
    break;

  case 157:
#line 1122 "swf4compiler.y"
    { (yyval.len) = bufferWriteOp(asmBuffer, SWFACTION_LOGICALAND); }
    break;

  case 158:
#line 1123 "swf4compiler.y"
    { (yyval.len) = bufferWriteOp(asmBuffer, SWFACTION_LOGICALOR); }
    break;

  case 159:
#line 1124 "swf4compiler.y"
    { (yyval.len) = bufferWriteOp(asmBuffer, SWFACTION_LOGICALNOT); }
    break;

  case 160:
#line 1125 "swf4compiler.y"
    { (yyval.len) = bufferWriteOp(asmBuffer, SWFACTION_STRINGCONCAT); }
    break;

  case 161:
#line 1126 "swf4compiler.y"
    { (yyval.len) = bufferWriteOp(asmBuffer, SWFACTION_STRINGEQ); }
    break;

  case 162:
#line 1127 "swf4compiler.y"
    { (yyval.len) = bufferWriteOp(asmBuffer, SWFACTION_STRINGLENGTH); }
    break;

  case 163:
#line 1128 "swf4compiler.y"
    { (yyval.len) = bufferWriteOp(asmBuffer, SWFACTION_SUBSTRING); }
    break;

  case 164:
#line 1129 "swf4compiler.y"
    { (yyval.len) = bufferWriteOp(asmBuffer, SWFACTION_MBSUBSTRING); }
    break;

  case 165:
#line 1130 "swf4compiler.y"
    { (yyval.len) = bufferWriteOp(asmBuffer, SWFACTION_MBLENGTH); }
    break;

  case 166:
#line 1131 "swf4compiler.y"
    { (yyval.len) = bufferWriteOp(asmBuffer, SWFACTION_STRINGCOMPARE); }
    break;

  case 167:
#line 1132 "swf4compiler.y"
    { (yyval.len) = bufferWriteOp(asmBuffer, SWFACTION_POP); }
    break;

  case 168:
#line 1133 "swf4compiler.y"
    { (yyval.len) = bufferWriteOp(asmBuffer, SWFACTION_CHR); }
    break;

  case 169:
#line 1134 "swf4compiler.y"
    { (yyval.len) = bufferWriteOp(asmBuffer, SWFACTION_ORD); }
    break;

  case 170:
#line 1135 "swf4compiler.y"
    { (yyval.len) = bufferWriteOp(asmBuffer, SWFACTION_INT); }
    break;

  case 171:
#line 1136 "swf4compiler.y"
    { (yyval.len) = bufferWriteOp(asmBuffer, SWFACTION_MBCHR); }
    break;

  case 172:
#line 1137 "swf4compiler.y"
    { (yyval.len) = bufferWriteOp(asmBuffer, SWFACTION_MBORD); }
    break;

  case 173:
#line 1138 "swf4compiler.y"
    { (yyval.len) = bufferWriteOp(asmBuffer, SWFACTION_CALLFRAME); }
    break;

  case 174:
#line 1139 "swf4compiler.y"
    { (yyval.len) = bufferWriteOp(asmBuffer, SWFACTION_GETVARIABLE); }
    break;

  case 175:
#line 1140 "swf4compiler.y"
    { (yyval.len) = bufferWriteOp(asmBuffer, SWFACTION_SETVARIABLE); }
    break;

  case 176:
#line 1141 "swf4compiler.y"
    { (yyval.len) = bufferWriteOp(asmBuffer, SWFACTION_GETPROPERTY); }
    break;

  case 177:
#line 1142 "swf4compiler.y"
    { (yyval.len) = bufferWriteOp(asmBuffer, SWFACTION_SETPROPERTY); }
    break;

  case 178:
#line 1143 "swf4compiler.y"
    { (yyval.len) = bufferWriteOp(asmBuffer, SWFACTION_REMOVECLIP); }
    break;

  case 179:
#line 1144 "swf4compiler.y"
    { (yyval.len) = bufferWriteOp(asmBuffer, SWFACTION_SETTARGET2); }
    break;

  case 180:
#line 1145 "swf4compiler.y"
    { (yyval.len) = bufferWriteOp(asmBuffer, SWFACTION_STARTDRAG); }
    break;

  case 181:
#line 1146 "swf4compiler.y"
    { (yyval.len) = bufferWriteOp(asmBuffer, SWFACTION_ENDDRAG); }
    break;

  case 182:
#line 1147 "swf4compiler.y"
    { (yyval.len) = bufferWriteOp(asmBuffer, SWFACTION_DUPLICATECLIP); }
    break;

  case 183:
#line 1148 "swf4compiler.y"
    { (yyval.len) = bufferWriteOp(asmBuffer, SWFACTION_GETTIME); }
    break;

  case 184:
#line 1149 "swf4compiler.y"
    { (yyval.len) = bufferWriteOp(asmBuffer, SWFACTION_RANDOMNUMBER); }
    break;

  case 185:
#line 1150 "swf4compiler.y"
    { (yyval.len) = bufferWriteOp(asmBuffer, SWFACTION_TRACE); }
    break;

  case 186:
#line 1152 "swf4compiler.y"
    { (yyval.len) = ( 
					bufferWriteOp(asmBuffer, SWFACTION_IF)
					+ bufferWriteS16(asmBuffer, 2)
					+ bufferWriteS16(asmBuffer, atoi((yyvsp[(2) - (2)].str)))); }
    break;

  case 187:
#line 1156 "swf4compiler.y"
    { (yyval.len) =  ( 
					bufferWriteOp(asmBuffer, SWFACTION_JUMP)
					+ bufferWriteS16(asmBuffer, 2)
					+ bufferWriteS16(asmBuffer, atoi((yyvsp[(2) - (2)].str)))); }
    break;

  case 188:
#line 1160 "swf4compiler.y"
    { (yyval.len) =  (bufferWriteOp(asmBuffer, SWFACTION_GETURL2)
					+ bufferWriteS16(asmBuffer, 1) 
					+ bufferWriteU8(asmBuffer, atoi((yyvsp[(2) - (2)].str)))); }
    break;

  case 189:
#line 1163 "swf4compiler.y"
    { (yyval.len) =  (bufferWriteOp(asmBuffer, SWFACTION_GOTOFRAME2) 
					+ bufferWriteS16(asmBuffer, 1)
					+ bufferWriteU8(asmBuffer, atoi((yyvsp[(2) - (2)].str)))); 
					/* SceneBias missing */ }
    break;

  case 190:
#line 1167 "swf4compiler.y"
    { (yyval.len) = (bufferWriteOp(asmBuffer, SWFACTION_WAITFORFRAME2) 
					+ bufferWriteS16(asmBuffer, 1)
					+ bufferWriteU8(asmBuffer, atoi((yyvsp[(2) - (2)].str)))); }
    break;


/* Line 1267 of yacc.c.  */
#line 3542 "swf4compiler.tab.c"
      default: break;
    }
  YY_SYMBOL_PRINT ("-> $$ =", yyr1[yyn], &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);

  *++yyvsp = yyval;


  /* Now `shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTOKENS] + *yyssp;
  if (0 <= yystate && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTOKENS];

  goto yynewstate;


/*------------------------------------.
| yyerrlab -- here on detecting error |
`------------------------------------*/
yyerrlab:
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
#if ! YYERROR_VERBOSE
      yyerror (YY_("syntax error"));
#else
      {
	YYSIZE_T yysize = yysyntax_error (0, yystate, yychar);
	if (yymsg_alloc < yysize && yymsg_alloc < YYSTACK_ALLOC_MAXIMUM)
	  {
	    YYSIZE_T yyalloc = 2 * yysize;
	    if (! (yysize <= yyalloc && yyalloc <= YYSTACK_ALLOC_MAXIMUM))
	      yyalloc = YYSTACK_ALLOC_MAXIMUM;
	    if (yymsg != yymsgbuf)
	      YYSTACK_FREE (yymsg);
	    yymsg = (char *) YYSTACK_ALLOC (yyalloc);
	    if (yymsg)
	      yymsg_alloc = yyalloc;
	    else
	      {
		yymsg = yymsgbuf;
		yymsg_alloc = sizeof yymsgbuf;
	      }
	  }

	if (0 < yysize && yysize <= yymsg_alloc)
	  {
	    (void) yysyntax_error (yymsg, yystate, yychar);
	    yyerror (yymsg);
	  }
	else
	  {
	    yyerror (YY_("syntax error"));
	    if (yysize != 0)
	      goto yyexhaustedlab;
	  }
      }
#endif
    }



  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse look-ahead token after an
	 error, discard it.  */

      if (yychar <= YYEOF)
	{
	  /* Return failure if at end of input.  */
	  if (yychar == YYEOF)
	    YYABORT;
	}
      else
	{
	  yydestruct ("Error: discarding",
		      yytoken, &yylval);
	  yychar = YYEMPTY;
	}
    }

  /* Else will try to reuse look-ahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:

  /* Pacify compilers like GCC when the user code never invokes
     YYERROR and the label yyerrorlab therefore never appears in user
     code.  */
  if (/*CONSTCOND*/ 0)
     goto yyerrorlab;

  /* Do not reclaim the symbols of the rule which action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;	/* Each real token shifted decrements this.  */

  for (;;)
    {
      yyn = yypact[yystate];
      if (yyn != YYPACT_NINF)
	{
	  yyn += YYTERROR;
	  if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYTERROR)
	    {
	      yyn = yytable[yyn];
	      if (0 < yyn)
		break;
	    }
	}

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
	YYABORT;


      yydestruct ("Error: popping",
		  yystos[yystate], yyvsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  *++yyvsp = yylval;


  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", yystos[yyn], yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;

/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;

#ifndef yyoverflow
/*-------------------------------------------------.
| yyexhaustedlab -- memory exhaustion comes here.  |
`-------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  /* Fall through.  */
#endif

yyreturn:
  if (yychar != YYEOF && yychar != YYEMPTY)
     yydestruct ("Cleanup: discarding lookahead",
		 yytoken, &yylval);
  /* Do not reclaim the symbols of the rule which action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
		  yystos[*yyssp], yyvsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
#if YYERROR_VERBOSE
  if (yymsg != yymsgbuf)
    YYSTACK_FREE (yymsg);
#endif
  /* Make sure YYID is used.  */
  return YYID (yyresult);
}


#line 1173 "swf4compiler.y"


