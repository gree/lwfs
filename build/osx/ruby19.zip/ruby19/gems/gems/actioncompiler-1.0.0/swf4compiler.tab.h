/* A Bison parser, made by GNU Bison 2.3.  */

/* Skeleton interface for Bison's Yacc-like parsers in C

   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
   Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor,
   Boston, MA 02110-1301, USA.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     BREAK = 258,
     FOR = 259,
     CONTINUE = 260,
     IF = 261,
     ELSE = 262,
     DO = 263,
     WHILE = 264,
     THIS = 265,
     EVAL = 266,
     TIME = 267,
     RANDOM = 268,
     LENGTH = 269,
     INT = 270,
     CONCAT = 271,
     DUPLICATECLIP = 272,
     REMOVECLIP = 273,
     TRACE = 274,
     STARTDRAG = 275,
     STOPDRAG = 276,
     ORD = 277,
     CHR = 278,
     CALLFRAME = 279,
     GETURL = 280,
     GETURL1 = 281,
     LOADMOVIE = 282,
     LOADMOVIENUM = 283,
     LOADVARIABLES = 284,
     POSTURL = 285,
     SUBSTR = 286,
     GETPROPERTY = 287,
     NEXTFRAME = 288,
     PREVFRAME = 289,
     PLAY = 290,
     STOP = 291,
     TOGGLEQUALITY = 292,
     STOPSOUNDS = 293,
     GOTOFRAME = 294,
     GOTOANDPLAY = 295,
     GOTOANDSTOP = 296,
     FRAMELOADED = 297,
     SETTARGET = 298,
     ASM = 299,
     ASMADD = 300,
     ASMDIVIDE = 301,
     ASMMULTIPLY = 302,
     ASMEQUALS = 303,
     ASMLESS = 304,
     ASMLOGICALAND = 305,
     ASMLOGICALOR = 306,
     ASMLOGICALNOT = 307,
     ASMSTRINGAND = 308,
     ASMSTRINGEQUALS = 309,
     ASMSTRINGEXTRACT = 310,
     ASMSTRINGLENGTH = 311,
     ASMMBSTRINGEXTRACT = 312,
     ASMMBSTRINGLENGTH = 313,
     ASMPOP = 314,
     ASMPUSH = 315,
     ASMASCIITOCHAR = 316,
     ASMCHARTOASCII = 317,
     ASMTOINTEGER = 318,
     ASMCALL = 319,
     ASMIF = 320,
     ASMJUMP = 321,
     ASMGETVARIABLE = 322,
     ASMSETVARIABLE = 323,
     ASMGETURL2 = 324,
     ASMGETPROPERTY = 325,
     ASMGOTOFRAME2 = 326,
     ASMREMOVESPRITE = 327,
     ASMSETPROPERTY = 328,
     ASMSETTARGET2 = 329,
     ASMSTARTDRAG = 330,
     ASMWAITFORFRAME2 = 331,
     ASMCLONESPRITE = 332,
     ASMENDDRAG = 333,
     ASMGETTIME = 334,
     ASMRANDOMNUMBER = 335,
     ASMTRACE = 336,
     ASMMBASCIITOCHAR = 337,
     ASMMBCHARTOASCII = 338,
     ASMSUBSTRACT = 339,
     ASMSTRINGLESS = 340,
     TELLTARGET = 341,
     BROKENSTRING = 342,
     STRING = 343,
     NUMBER = 344,
     IDENTIFIER = 345,
     PATH = 346,
     EQ = 347,
     LE = 348,
     GE = 349,
     NE = 350,
     LAN = 351,
     LOR = 352,
     INC = 353,
     DEC = 354,
     IEQ = 355,
     DEQ = 356,
     MEQ = 357,
     SEQ = 358,
     STREQ = 359,
     STRNE = 360,
     STRCMP = 361,
     PARENT = 362,
     END = 363,
     UMINUS = 364,
     POSTFIX = 365,
     NEGATE = 366
   };
#endif
/* Tokens.  */
#define BREAK 258
#define FOR 259
#define CONTINUE 260
#define IF 261
#define ELSE 262
#define DO 263
#define WHILE 264
#define THIS 265
#define EVAL 266
#define TIME 267
#define RANDOM 268
#define LENGTH 269
#define INT 270
#define CONCAT 271
#define DUPLICATECLIP 272
#define REMOVECLIP 273
#define TRACE 274
#define STARTDRAG 275
#define STOPDRAG 276
#define ORD 277
#define CHR 278
#define CALLFRAME 279
#define GETURL 280
#define GETURL1 281
#define LOADMOVIE 282
#define LOADMOVIENUM 283
#define LOADVARIABLES 284
#define POSTURL 285
#define SUBSTR 286
#define GETPROPERTY 287
#define NEXTFRAME 288
#define PREVFRAME 289
#define PLAY 290
#define STOP 291
#define TOGGLEQUALITY 292
#define STOPSOUNDS 293
#define GOTOFRAME 294
#define GOTOANDPLAY 295
#define GOTOANDSTOP 296
#define FRAMELOADED 297
#define SETTARGET 298
#define ASM 299
#define ASMADD 300
#define ASMDIVIDE 301
#define ASMMULTIPLY 302
#define ASMEQUALS 303
#define ASMLESS 304
#define ASMLOGICALAND 305
#define ASMLOGICALOR 306
#define ASMLOGICALNOT 307
#define ASMSTRINGAND 308
#define ASMSTRINGEQUALS 309
#define ASMSTRINGEXTRACT 310
#define ASMSTRINGLENGTH 311
#define ASMMBSTRINGEXTRACT 312
#define ASMMBSTRINGLENGTH 313
#define ASMPOP 314
#define ASMPUSH 315
#define ASMASCIITOCHAR 316
#define ASMCHARTOASCII 317
#define ASMTOINTEGER 318
#define ASMCALL 319
#define ASMIF 320
#define ASMJUMP 321
#define ASMGETVARIABLE 322
#define ASMSETVARIABLE 323
#define ASMGETURL2 324
#define ASMGETPROPERTY 325
#define ASMGOTOFRAME2 326
#define ASMREMOVESPRITE 327
#define ASMSETPROPERTY 328
#define ASMSETTARGET2 329
#define ASMSTARTDRAG 330
#define ASMWAITFORFRAME2 331
#define ASMCLONESPRITE 332
#define ASMENDDRAG 333
#define ASMGETTIME 334
#define ASMRANDOMNUMBER 335
#define ASMTRACE 336
#define ASMMBASCIITOCHAR 337
#define ASMMBCHARTOASCII 338
#define ASMSUBSTRACT 339
#define ASMSTRINGLESS 340
#define TELLTARGET 341
#define BROKENSTRING 342
#define STRING 343
#define NUMBER 344
#define IDENTIFIER 345
#define PATH 346
#define EQ 347
#define LE 348
#define GE 349
#define NE 350
#define LAN 351
#define LOR 352
#define INC 353
#define DEC 354
#define IEQ 355
#define DEQ 356
#define MEQ 357
#define SEQ 358
#define STREQ 359
#define STRNE 360
#define STRCMP 361
#define PARENT 362
#define END 363
#define UMINUS 364
#define POSTFIX 365
#define NEGATE 366




#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
#line 19 "swf4compiler.y"
{
  Buffer action;
  char *str;
  SWFActionFunction function;
  SWFGetUrl2Method getURLMethod;
  int len;
}
/* Line 1529 of yacc.c.  */
#line 279 "swf4compiler.tab.h"
	YYSTYPE;
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif

extern YYSTYPE swf4lval;

